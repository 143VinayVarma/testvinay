package utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Properties;

public class TestSuiteUtil {
	
	private static final String SERVICE_CONFIG_DIR = "src/test/java/utilities/testSuiteConfig.properties";
	private static Properties prop = null;
	private static long lastPropReadModifiedTime = -1L;
	private static boolean hasConfigFile = false;
	
	public static ArrayList<File> retrieveFileList(String filePath) {
		File file = new File(filePath);
		if (file != null && file.exists()) {
			File[] listOfFiles = file.listFiles();
			ArrayList<File> fileList = new ArrayList<File>(Arrays.asList(listOfFiles));
			return fileList;
		}
		return null;
	}
	
	public static LinkedHashMap<File, File> retrieveRequestResponseMap(ArrayList<File> requestList, ArrayList<File> responseList){
		LinkedHashMap<File, File> requestResponseMap = new LinkedHashMap<File, File>();
		for (int i = 0; i < requestList.size(); i++) {
			requestResponseMap.put(requestList.get(i), responseList.get(i));
		}
		return requestResponseMap;
	}
	
	/**
	 * Retrieve properties for service
	 * 
	 * @return {@code Properties}
	 */
	public static Properties loadProperties() {
		File configFile = new File(SERVICE_CONFIG_DIR);
			if (configFile.exists()) {
				hasConfigFile = true;
				if (configFile.lastModified() != lastPropReadModifiedTime) {
					prop = new Properties();
					lastPropReadModifiedTime = configFile.lastModified();
					FileInputStream configFileStream = null;
					try {
						configFileStream = new FileInputStream(configFile);
						prop.load(configFileStream);
					} catch (Exception e) {
					} finally {
						if (configFileStream != null) {
							try {
								configFileStream.close();
							} catch (IOException ioError) {
							}
						}
				}
			} else {
				hasConfigFile = false;
			}
		}
		return prop;
	}
	
	/**
	 * Indicates if config file has been found:
	 * true = found 
	 * false = not found
	 * 
	 * @return {@code boolean}
	 */
	public static boolean hasConfigFile() {
		loadProperties();
		return hasConfigFile;
	}
	
	public static String getUserID() {
		Properties properties = TestSuiteUtil.loadProperties();
		return properties.getProperty("user_id");
	}
	
	public static String getUserName() {
		Properties properties = TestSuiteUtil.loadProperties();
		return properties.getProperty("user_name");
	}
	
	public static String getPassword() {
		Properties properties = TestSuiteUtil.loadProperties();
		return properties.getProperty("password");
	}
	
	public static String getBaseURL() {
		Properties properties = TestSuiteUtil.loadProperties();
		return properties.getProperty("base_url");
	}
	
	public static String getSender() {
		Properties properties = TestSuiteUtil.loadProperties();
		return properties.getProperty("sender");
	}
	
	public static String getHost() {
		Properties properties = TestSuiteUtil.loadProperties();
		return properties.getProperty("host");
	}
	
	public static String getResultFile() {
		Properties properties = TestSuiteUtil.loadProperties();
		return properties.getProperty("resultFile");
	}
	
	public static String getSmtpFormat() {
		Properties properties = TestSuiteUtil.loadProperties();
		return properties.getProperty("smtpFormat");
	}
	
	public static String getRecipeintList() {
		Properties properties = TestSuiteUtil.loadProperties();
		return properties.getProperty("recipients");
	}
	
	public static String getCarbonCopyList() {
		Properties properties = TestSuiteUtil.loadProperties();
		return properties.getProperty("carbonCopy");
	}
	
	public static boolean getLoggerStatusForStepDefinition() {
		Properties properties = TestSuiteUtil.loadProperties();
		String flag = properties.getProperty("StepDefinitions");
		if(flag.equals("true")) {
			return true;
		}else {
			return false;
		}
	}
	

}
