$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("End2EndTest.feature");
formatter.feature({
  "line": 1,
  "name": "End to End test for ToolsQA\u0027s book store API",
  "description": "",
  "id": "end-to-end-test-for-toolsqa\u0027s-book-store-api",
  "keyword": "Feature"
});
formatter.background({
  "line": 3,
  "name": "User generates token for Authorisation",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "I am an authorized user",
  "keyword": "Given "
});
formatter.match({
  "location": "Steps.iAmAnAuthorizedUser()"
});
formatter.result({
  "duration": 4321603648,
  "status": "passed"
});
formatter.scenario({
  "line": 6,
  "name": "the Authorized user can Add and Remove a book.",
  "description": "",
  "id": "end-to-end-test-for-toolsqa\u0027s-book-store-api;the-authorized-user-can-add-and-remove-a-book.",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 7,
  "name": "A list of books are available",
  "keyword": "Given "
});
formatter.step({
  "line": 8,
  "name": "I add a book to my reading list",
  "keyword": "When "
});
formatter.step({
  "line": 9,
  "name": "the book is added",
  "keyword": "Then "
});
formatter.step({
  "line": 10,
  "name": "I remove a book from my reading list",
  "keyword": "When "
});
formatter.step({
  "line": 11,
  "name": "the book is removed",
  "keyword": "Then "
});
formatter.match({
  "location": "Steps.listOfBooksAreAvailable()"
});
formatter.result({
  "duration": 1711867414,
  "status": "passed"
});
formatter.match({
  "location": "Steps.addBookInList()"
});
formatter.result({
  "duration": 1537637860,
  "status": "passed"
});
formatter.match({
  "location": "Steps.the_book_is_added()"
});
formatter.result({
  "duration": 311882,
  "status": "passed"
});
formatter.match({
  "location": "Steps.removeBookFromList()"
});
formatter.result({
  "duration": 1296955525,
  "status": "passed"
});
formatter.match({
  "location": "Steps.the_book_is_removed()"
});
formatter.result({
  "duration": 2255193157,
  "status": "passed"
});
});