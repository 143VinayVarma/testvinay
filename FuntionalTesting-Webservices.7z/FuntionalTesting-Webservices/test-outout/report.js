$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("features.feature");
formatter.feature({
  "line": 1,
  "name": "Rest Api testing scenario",
  "description": "",
  "id": "rest-api-testing-scenario",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 3,
  "name": "Verify rest api status",
  "description": "",
  "id": "rest-api-testing-scenario;verify-rest-api-status",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "the end point \"restAPI\"",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "invoke SoapUI",
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "restAPI",
      "offset": 15
    }
  ],
  "location": "StepDefinition.the_end_point(String)"
});
formatter.result({
  "duration": 65344741693,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.invoke_SoapUI()"
});
formatter.result({
  "duration": 21381714052,
  "status": "passed"
});
});