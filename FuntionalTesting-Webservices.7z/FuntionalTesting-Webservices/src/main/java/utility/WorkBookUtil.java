package utility;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import utility.XSCMRequestType.I6609ReqAcctInfo;
import utility.XSCMRequestType.I6609ReqAesInfo;
import utility.XSCMRequestType.I6609ReqAssocInfo;
import utility.XSCMRequestType.I6609ReqCustInfo;
import utility.XSCMRequestType.I6609ReqOriginInfo;
import utility.XSCMRequestType.I6609ReqTerminalInfo;

public class WorkBookUtil {

	SimpleDateFormat f = new SimpleDateFormat("yyyyMMdd HH:mm:ss");
	String dateFormat = f.format(new Date());
	String dateForDD = dateFormat.substring(0, 8);
	String timeForDD = dateFormat.substring(9, dateFormat.length()).replace(":", "");
	static Logger logger = Logger.getLogger(WorkBookUtil.class);
	static boolean activateLogger = TestSuiteUtil.getLoggerStatusForWorkBookUtil();

	public Map<String, List<XSCMRequestType>> prepareSheetData(Workbook requestWorkBook) {	
		Map<String, List<XSCMRequestType>> requestTypeMap = new LinkedHashMap<>();
		try {
			for (int k = 0; k < 1; k++) {
				String sheetName = requestWorkBook.getSheetName(k);
				List<XSCMRequestType> requestTypes = getData(requestWorkBook, sheetName);
				requestTypeMap.put(sheetName, requestTypes);
			}
		} catch (Exception e) {
			e.getMessage();
		}
		return requestTypeMap;
	}

	public List<XSCMRequestType> getData(Workbook requestWorkBook, String sheetName) {
		Sheet sheet1 = requestWorkBook.getSheet(sheetName);
		List<XSCMRequestType> requestTypes = new ArrayList<>();
		Integer rowCount = sheet1.getLastRowNum();
		Map<Integer, String> headerMap = new HashMap<Integer, String>();
		short firstCellNumber = sheet1.getRow(0).getFirstCellNum();
		short lastCellNumber = sheet1.getRow(0).getLastCellNum();
		for (int cellCount = firstCellNumber; cellCount < lastCellNumber; cellCount++) {
			headerMap.put(cellCount, sheet1.getRow(0).getCell(cellCount).toString());
		}
		for (Integer rowNum = 1; rowNum <= rowCount; rowNum++) {
			Row row = sheet1.getRow(rowNum);
			XSCMRequestType requestType = getRow(row, headerMap);
			requestTypes.add(requestType);
		}
		return requestTypes;
	}

	public XSCMRequestType getRow(Row row, Map<Integer, String> headerMap) {
		XSCMRequestType requestType = new XSCMRequestType();
		XSCMRequestType.I6609ReqAcctInfo acctInfo = new I6609ReqAcctInfo();
		XSCMRequestType.I6609ReqOriginInfo originInfo = new I6609ReqOriginInfo();
		XSCMRequestType.I6609ReqAesInfo aesInfo = new I6609ReqAesInfo();
		XSCMRequestType.I6609ReqCustInfo custInfo = new I6609ReqCustInfo();
		XSCMRequestType.I6609ReqTerminalInfo terminfo = new I6609ReqTerminalInfo();
		XSCMRequestType.I6609ReqAssocInfo associnfo = new I6609ReqAssocInfo();
		short firstCellNumber = row.getFirstCellNum();
		short lastCellNumber = row.getLastCellNum();
		for (int cellCount = firstCellNumber + 1; cellCount < lastCellNumber; cellCount++) {
			String columnName = headerMap.get(cellCount);
			switch (columnName) {
			case "version":
				if (row.getCell(cellCount).getCellType() == 0) {
					requestType.setVersion((int) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 1) {
					requestType.setVersion(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "client-id":
				if (row.getCell(cellCount).getCellType() == 0) {
					requestType.setClientId((int) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 1) {
					requestType.setClientId(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "subclient-id":
				if (row.getCell(cellCount).getCellType() == 0) {
					requestType.setSubclientId((int) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 1) {
					requestType.setSubclientId(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-action":
				if (row.getCell(cellCount).getCellType() == 0) {
					requestType.setI6609ReqAction((int) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 1) {
					requestType.setI6609ReqAction(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-cond-code":
				if (row.getCell(cellCount).getCellType() == 1) {
					requestType.setI6609ReqCondCode(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 0) {
					requestType.setI6609ReqCondCode((int) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-division":
				if (row.getCell(cellCount).getCellType() == 1) {
					originInfo.setI6609ReqDivision(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 0) {
					originInfo.setI6609ReqDivision((int) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-store-no":
				if (row.getCell(cellCount).getCellType() == 0) {
					originInfo.setI6609ReqStoreNo((int) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 1) {
					originInfo.setI6609ReqStoreNo(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-term-no":
				if (row.getCell(cellCount).getCellType() == 0) {
					originInfo.setI6609ReqTermNo((int) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 1) {
					originInfo.setI6609ReqTermNo(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-trans-no":
				if (row.getCell(cellCount).getCellType() == 0) {
					originInfo.setI6609ReqTransNo(((long) row.getCell(cellCount).getNumericCellValue() + ""));
				} else if (row.getCell(cellCount).getCellType() == 1) {
					originInfo.setI6609ReqTransNo(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-seq-no":
				if (row.getCell(cellCount).getCellType() == 0) {
					originInfo.setI6609ReqSeqNo((long) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 1) {
					originInfo.setI6609ReqSeqNo(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;

			case "i6609-req-orig-tran-cd":
				if (row.getCell(cellCount).getCellType() == 0) {
					originInfo.setI6609ReqOrigTranCd((long) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 1) {
					originInfo.setI6609ReqOrigTranCd(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-orig-tran-dt":
				if (row.getCell(cellCount).getCellType() == 0) {
					originInfo.setI6609ReqOrigTranDt(dateForDD + "");
				} else if (row.getCell(cellCount).getCellType() == 1) {
					originInfo.setI6609ReqOrigTranDt(dateForDD + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;

			case "i6609-req-orig-tran-tm":
				if (row.getCell(cellCount).getCellType() == 0) {
					originInfo.setI6609ReqOrigTranTm(timeForDD + "");
				} else if (row.getCell(cellCount).getCellType() == 1) {
					originInfo.setI6609ReqOrigTranTm(timeForDD + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-orig-tran-no":
				if (row.getCell(cellCount).getCellType() == 0) {
					originInfo.setI6609ReqOrigTranNo((long) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 1) {
					originInfo.setI6609ReqOrigTranNo(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-unique-id":
				if (row.getCell(cellCount).getCellType() == 1) {
					originInfo.setI6609ReqUniqueId(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 0) {
					originInfo.setI6609ReqUniqueId((int) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-card-type":
				if (row.getCell(cellCount).getCellType() == 1) {
					acctInfo.setI6609ReqCardType(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 0) {
					acctInfo.setI6609ReqCardType((int) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-3p-gift-type":
				if (row.getCell(cellCount).getCellType() == 1) {
					acctInfo.setI6609Req3PGiftType(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 0) {
					acctInfo.setI6609Req3PGiftType(((int) row.getCell(cellCount).getNumericCellValue() + ""));
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-acct-fmt":
				if (row.getCell(cellCount).getCellType() == 1) {
					acctInfo.setI6609ReqAcctFmt(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 0) {
					acctInfo.setI6609ReqAcctFmt((int) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-acct-no":
				if (row.getCell(cellCount).getCellType() == 1) {
					acctInfo.setI6609ReqAcctNo(row.getCell(cellCount).getStringCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 0) {
					acctInfo.setI6609ReqAcctNo((long) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-entry-mode":
				if (row.getCell(cellCount).getCellType() == 1) {
					acctInfo.setI6609ReqEntryMode(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 0) {
					acctInfo.setI6609ReqEntryMode((int) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-fallback-cd":
				if (row.getCell(cellCount).getCellType() == 1) {
					acctInfo.setI6609ReqFallbackCd(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 0) {
					acctInfo.setI6609ReqFallbackCd((int) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-card-emv-capable":
				if (row.getCell(cellCount).getCellType() == 1) {
					acctInfo.setI6609ReqCardEmvCapable(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 0) {
					acctInfo.setI6609ReqCardEmvCapable((int) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-emv-cvm":
				if (row.getCell(cellCount).getCellType() == 1) {
					acctInfo.setI6609ReqEmvCvm(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 0) {
					acctInfo.setI6609ReqEmvCvm((int) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-exp-date":
				if (row.getCell(cellCount).getCellType() == 1) {
					acctInfo.setI6609ReqExpDate(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 0) {
					acctInfo.setI6609ReqExpDate((int) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
					acctInfo.setI6609ReqExpDate("1712" + "");
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-prop-acct-type":
				if (row.getCell(cellCount).getCellType() == 1) {
					acctInfo.setI6609ReqPropAcctType(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 0) {
					acctInfo.setI6609ReqPropAcctType((int) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-cid":
				if (row.getCell(cellCount).getCellType() == 1) {
					acctInfo.setI6609ReqCid(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 0) {
					acctInfo.setI6609ReqCid((int) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-track1-data":
				if (row.getCell(cellCount).getCellType() == 1) {
					acctInfo.setI6609ReqTrack1Data(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 0) {
					acctInfo.setI6609ReqTrack1Data(row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-track2-data":
				if (row.getCell(cellCount).getCellType() == 1) {
					acctInfo.setI6609ReqTrack2Data(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 0) {
					acctInfo.setI6609ReqTrack2Data(row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-icc-data":
				if (row.getCell(cellCount).getCellType() == 1) {
					acctInfo.setI6609ReqIccData(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 0) {
					acctInfo.setI6609ReqIccData((int) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-icc-card-seq-no":
				if (row.getCell(cellCount).getCellType() == 0) {
					acctInfo.setI6609ReqIccCardSeqNo((int) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 1) {
					acctInfo.setI6609ReqIccCardSeqNo(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-serial-nbr":
				if (row.getCell(cellCount).getCellType() == 0) {
					acctInfo.setI6609ReqSerialNbr((int) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 1) {
					acctInfo.setI6609ReqSerialNbr(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-pin-block":
				if (row.getCell(cellCount).getCellType() == 1) {
					acctInfo.setI6609ReqPinBlock(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 0) {
					acctInfo.setI6609ReqPinBlock((int) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-amount":
				if (row.getCell(cellCount).getCellType() == 1) {
					requestType.setI6609ReqAmount(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 0) {
					requestType.setI6609ReqAmount((long) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-sell-assoc-no1":
				if (row.getCell(cellCount).getCellType() == 1) {
					associnfo.setI6609ReqSellAssocNo1(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 0) {
					associnfo.setI6609ReqSellAssocNo1((long) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-sell-assoc-no2":
				if (row.getCell(cellCount).getCellType() == 1) {
					associnfo.setI6609ReqSellAssocNo2(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 0) {
					associnfo.setI6609ReqSellAssocNo2((long) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-ring-assoc-no":
				if (row.getCell(cellCount).getCellType() == 1) {
					associnfo.setI6609ReqRingAssocNo(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 0) {
					associnfo.setI6609ReqRingAssocNo((long) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-dept-no":
				if (row.getCell(cellCount).getCellType() == 1) {
					requestType.setI6609ReqDeptNo(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 0) {
					requestType.setI6609ReqDeptNo((int) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-presale-eff-dt":
				if (row.getCell(cellCount).getCellType() == 1) {
					requestType.setI6609ReqPresaleEffDt(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 0) {
					requestType.setI6609ReqPresaleEffDt((long) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-form-of-pmt":
				if (row.getCell(cellCount).getCellType() == 1) {
					requestType.setI6609ReqFormOfPmt(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 0) {
					requestType.setI6609ReqFormOfPmt((int) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-cust-id":
				if (row.getCell(cellCount).getCellType() == 1) {
					custInfo.setI6609ReqCustId(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 0) {
					custInfo.setI6609ReqCustId((long) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-cust-state":
				if (row.getCell(cellCount).getCellType() == 1) {
					custInfo.setI6609ReqCustState(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 0) {
					custInfo.setI6609ReqCustState(row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-fis-entry-meth":
				if (row.getCell(cellCount).getCellType() == 1) {
					custInfo.setI6609ReqFisEntryMeth(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 0) {
					custInfo.setI6609ReqFisEntryMeth(row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-fis-id-type":
				if (row.getCell(cellCount).getCellType() == 1) {
					custInfo.setI6609ReqFisIdType(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 0) {
					custInfo.setI6609ReqFisIdType(row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-fis-flag":
				if (row.getCell(cellCount).getCellType() == 1) {
					custInfo.setI6609ReqFisFlag(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 0) {
					custInfo.setI6609ReqFisFlag(row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-avs-addr":
				if (row.getCell(cellCount).getCellType() == 1) {
					custInfo.setI6609ReqAvsAddr(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 0) {
					custInfo.setI6609ReqAvsAddr(row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-cust-zip":
				if (row.getCell(cellCount).getCellType() == 1) {
					custInfo.setI6609ReqCustZip(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 0) {
					custInfo.setI6609ReqCustZip((int) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-income-amt":
				if (row.getCell(cellCount).getCellType() == 1) {
					custInfo.setI6609ReqIncomeAmt(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 0) {
					custInfo.setI6609ReqIncomeAmt((long) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-house-exp-type":
				if (row.getCell(cellCount).getCellType() == 1) {
					custInfo.setI6609ReqHouseExpType(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 0) {
					custInfo.setI6609ReqHouseExpType(row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-house-exp-mmp":
				if (row.getCell(cellCount).getCellType() == 1) {
					custInfo.setI6609ReqHouseExpMmp(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 0) {
					custInfo.setI6609ReqHouseExpMmp((long) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-aes-div":
				if (row.getCell(cellCount).getCellType() == 1) {
					aesInfo.setI6609ReqAesDiv(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 0) {
					aesInfo.setI6609ReqAesDiv((int) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-aes-store":
				if (row.getCell(cellCount).getCellType() == 1) {
					aesInfo.setI6609ReqAesStore(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 0) {
					aesInfo.setI6609ReqAesStore((int) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-aes-ver-no":
				if (row.getCell(cellCount).getCellType() == 1) {
					aesInfo.setI6609ReqAesVerNo(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 0) {
					aesInfo.setI6609ReqAesVerNo((long) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-cust-id-aesver-no":
				if (row.getCell(cellCount).getCellType() == 1) {
					requestType.setI6609ReqCustIdAesverNo(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 0) {
					requestType.setI6609ReqCustIdAesverNo((long) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-trans-stat":
				if (row.getCell(cellCount).getCellType() == 1) {
					requestType.setI6609ReqTransStat(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 0) {
					requestType.setI6609ReqTransStat((int) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-task-id":
				if (row.getCell(cellCount).getCellType() == 0) {
					requestType.setI6609ReqTaskId((int) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 1) {
					requestType.setI6609ReqTaskId(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-amex-ref-numb":
				if (row.getCell(cellCount).getCellType() == 0) {
					requestType.setI6609ReqAmexRefNumb((int) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 1) {
					requestType.setI6609ReqAmexRefNumb(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-pin-ent-cap":
				if (row.getCell(cellCount).getCellType() == 1) {
					terminfo.setI6609ReqPinEntCap(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else if (row.getCell(cellCount).getCellType() == 0) {
					terminfo.setI6609ReqPinEntCap((int) row.getCell(cellCount).getNumericCellValue() + "");
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-term-ent-cap":
				if (row.getCell(cellCount).getCellType() == 1) {
					terminfo.setI6609ReqTermEntCap(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 0) {
					terminfo.setI6609ReqTermEntCap((int) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-term-dev-mdl":
				if (row.getCell(cellCount).getCellType() == 1) {
					terminfo.setI6609ReqTermDevMdl(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 0) {
					terminfo.setI6609ReqTermDevMdl(row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-term-app-name":
				if (row.getCell(cellCount).getCellType() == 1) {
					terminfo.setI6609ReqTermAppName(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 0) {
					terminfo.setI6609ReqTermAppName(row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-term-app-ver":
				if (row.getCell(cellCount).getCellType() == 1) {
					terminfo.setI6609ReqTermAppVer(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else if (row.getCell(cellCount).getCellType() == 0) {
					terminfo.setI6609ReqTermAppVer((int) row.getCell(cellCount).getNumericCellValue() + "");
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-reserv-number":
				if (row.getCell(cellCount).getCellType() == 1) {
					requestType.setI6609ReqReservNumber(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 0) {
					requestType.setI6609ReqReservNumber((long) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-batch-indicator":
				if (row.getCell(cellCount).getCellType() == 0) {
					requestType.setI6609ReqBatchIndicator(row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 1) {
					requestType.setI6609ReqBatchIndicator(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-eci-indicator":
				if (row.getCell(cellCount).getCellType() == 1) {
					requestType.setI6609EciIndicator(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 0) {
					requestType.setI6609EciIndicator((long) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-3d-secure-cryptogram":
				if (row.getCell(cellCount).getCellType() == 0) {
					requestType.setI66093DSecureCryptogram(row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 1) {
					requestType.setI66093DSecureCryptogram(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-3d-sec-cavv":
				if (row.getCell(cellCount).getCellType() == 0) {
					requestType.setI66093DSecCavv(row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 1) {
					requestType.setI66093DSecCavv(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-3d-sec-xid":
				if (row.getCell(cellCount).getCellType() == 0) {
					requestType.setI66093DSecXid((int) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 1) {
					requestType.setI66093DSecXid(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-for-conv-rate":
				if (row.getCell(cellCount).getCellType() == 0) {
					requestType.setI6609ReqForConvRate(row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 1) {
					requestType.setI6609ReqForConvRate(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-for-curr-code":
				if (row.getCell(cellCount).getCellType() == 1) {
					requestType.setI6609ReqForCurrCode(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 0) {
					requestType.setI6609ReqForCurrCode((long) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-for-curr-amt":
				if (row.getCell(cellCount).getCellType() == 0) {
					requestType.setI6609ReqForCurrAmt(row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 1) {
					requestType.setI6609ReqForCurrAmt(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-dcc-option-flag":
				if (row.getCell(cellCount).getCellType() == 1) {
					requestType.setI6609ReqDccOptionFlag(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 0) {
					requestType.setI6609ReqDccOptionFlag(row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			case "i6609-req-dcc-2-pass-flag":
				if (row.getCell(cellCount).getCellType() == 0) {
					requestType.setI6609ReqDcc2PassFlag((int) row.getCell(cellCount).getNumericCellValue() + "");
				} else if (row.getCell(cellCount).getCellType() == 1) {
					requestType.setI6609ReqDcc2PassFlag(row.getCell(cellCount).getStringCellValue());
				} else if (row.getCell(cellCount).getCellType() == 3) {
				} else {
					display(activateLogger, columnName);
				}
				break;
			}
		}
		requestType.setI6609ReqOriginInfo(originInfo);
		requestType.setI6609ReqAcctInfo(acctInfo);
		requestType.setI6609ReqAssocInfo(associnfo);
		requestType.setI6609ReqAesInfo(aesInfo);
		requestType.setI6609ReqCustInfo(custInfo);
		requestType.setI6609ReqTerminalInfo(terminfo);
		return requestType;
	}

	public void display(boolean activateLogger, String requestField) {
		if (!activateLogger) {
			System.err.println("Please check the cell format of " + requestField);
		} else {
			logger.error("Please check the cell format of " + requestField);
		}
	}

}
