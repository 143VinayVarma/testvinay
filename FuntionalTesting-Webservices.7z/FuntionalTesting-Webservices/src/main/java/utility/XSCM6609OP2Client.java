package utility;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Unmarshaller;
import javax.xml.namespace.QName;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.Node;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPHeaderElement;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Workbook;

import utility.XSCMRequestType;
import utility.XSCMResponseType;

public class XSCM6609OP2Client {
	String fs;
	Workbook wb1;
	int rowcount;
	String[] rspstoreno = new String[100];
	static Logger logger = Logger.getLogger(XSCM6609OP2Client.class);
	static boolean activateLoggerForXSCM6609OP2Client = TestSuiteUtil.getLoggerStatusForXSCM6609OP2Client();
	static boolean activateLoggersForParamsAdded = TestSuiteUtil.getLoggerStatusForAddingParams();

	public XSCMResponseType callWebService(String soapEndpointUrl, XSCMRequestType requestType, String uri,
			String password, File requestFile, File responseFile, Integer count) throws SOAPException, IOException {
		SOAPMessage soapMessage = createSOAPRequest(uri, requestType, password, requestFile, responseFile, count);
		if (activateLoggerForXSCM6609OP2Client) {
			ByteArrayOutputStream requestOut = new ByteArrayOutputStream();
			soapMessage.writeTo(requestOut);
			String reqOut = new String(requestOut.toByteArray());
			logger.debug("request--->" + reqOut);
			System.out.println("\n");
			requestOut.flush();
		}
		System.out.println("request--->");
		soapMessage.writeTo(System.out);
		System.out.println("\n");
		XSCMResponseType irnOutputInterface = callSoapWebService(soapMessage, soapEndpointUrl, uri, password);
		return irnOutputInterface;
	}

	private XSCMResponseType callSoapWebService(SOAPMessage soapMessage, String soapEndpointUrl, String uri,
			String password) {
		XSCMResponseType irnOutputInterface = new XSCMResponseType();
		try {
			SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
			SOAPConnection soapConnection = soapConnectionFactory.createConnection();
			SOAPMessage soapResponse = soapConnection.call(soapMessage, soapEndpointUrl);
			System.out.println("response--->");
			soapResponse.writeTo(System.out);
			if (activateLoggerForXSCM6609OP2Client) {
				ByteArrayOutputStream responseOut = new ByteArrayOutputStream();
				soapResponse.writeTo(responseOut);
				String respOut = new String(responseOut.toByteArray());
				logger.debug("response--->" + respOut);
				System.out.println("\n");
				responseOut.flush();
			}
			SOAPPart soapPart = soapResponse.getSOAPPart();
			SOAPEnvelope envelope = soapPart.getEnvelope();
			SOAPBody soapBody = envelope.getBody();
			@SuppressWarnings("unchecked")
			Iterator<Node> itr = soapBody.getChildElements();
			JAXBContext jbc = JAXBContext.newInstance(XSCMResponseType.class);
			Unmarshaller um = jbc.createUnmarshaller();
			while (itr.hasNext()) {
				Node node = (Node) itr.next();
				JAXBElement<XSCMResponseType> element = um.unmarshal(node, XSCMResponseType.class);
				irnOutputInterface = element.getValue();
			}
			System.out.println("\n");
			soapConnection.close();
			return irnOutputInterface;
		} catch (Exception e) {
			return new XSCMResponseType();
		}
	}

	@SuppressWarnings("unused")
	private void createSoapEnvelope(SOAPMessage soapMessage, String uri, XSCMRequestType requestType, File requestFile,
			File responseFile, Integer count) {
		try {
			SOAPPart soapPart = soapMessage.getSOAPPart();
			String myNamespace = "ns2";
			SOAPEnvelope envelope = soapPart.getEnvelope();
			envelope.addNamespaceDeclaration(myNamespace, uri);
			SOAPBody soapBody1 = envelope.getBody();
			if (activateLoggerForXSCM6609OP2Client) {
				logger.debug("processing from>>>>> " + requestFile.toString());
				logger.debug("request number--->" + count);
			} else {
				System.out.println("processing from>>>>>> " + requestFile.toString());
				System.out.println("request number--->" + count);
			}
			SOAPElement soapBody = soapBody1.addChildElement("op2-request", myNamespace);
			if (requestType.getI6609ReqAction() != "" && requestType.getI6609ReqAction() != null) {
				SOAPElement soapBodyElem = soapBody.addChildElement("i6609-req-action", myNamespace)
						.addTextNode(requestType.getI6609ReqAction() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added I6609ReqAction to request");
				}
			}
			if (requestType.getI6609ReqCondCode() != "" && requestType.getI6609ReqCondCode() != null) {
				SOAPElement soapBodyElem1 = soapBody.addChildElement("i6609-req-cond-code", myNamespace)
						.addTextNode(requestType.getI6609ReqCondCode() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqCondCode to request");
				}
			}
			SOAPElement reqOriginInfo = soapBody.addChildElement("i6609-req-origin-info", myNamespace);
			if (requestType.getI6609ReqOriginInfo().getI6609ReqDivision() != ""
					&& requestType.getI6609ReqOriginInfo().getI6609ReqDivision() != null) {
				SOAPElement reqOriginInfoElem1 = reqOriginInfo.addChildElement("i6609-req-division", myNamespace)
						.addTextNode(requestType.getI6609ReqOriginInfo().getI6609ReqDivision() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqDivision to request");
				}
			}
			if (requestType.getI6609ReqOriginInfo().getI6609ReqStoreNo() != ""
					&& requestType.getI6609ReqOriginInfo().getI6609ReqStoreNo() != null) {
				SOAPElement reqOriginInfoElem2 = reqOriginInfo.addChildElement("i6609-req-store-no", myNamespace)
						.addTextNode(requestType.getI6609ReqOriginInfo().getI6609ReqStoreNo() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqStoreNo to request");
				}
			}
			if (requestType.getI6609ReqOriginInfo().getI6609ReqTermNo() != ""
					&& requestType.getI6609ReqOriginInfo().getI6609ReqTermNo() != null) {
				SOAPElement reqOriginInfoElem3 = reqOriginInfo.addChildElement("i6609-req-term-no", myNamespace)
						.addTextNode(requestType.getI6609ReqOriginInfo().getI6609ReqTermNo() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqTermNo to request");
				}
			}
			if (requestType.getI6609ReqOriginInfo().getI6609ReqTransNo() != ""
					&& requestType.getI6609ReqOriginInfo().getI6609ReqTransNo() != null) {
				SOAPElement reqOriginInfoElem4 = reqOriginInfo.addChildElement("i6609-req-trans-no", myNamespace)
						.addTextNode(requestType.getI6609ReqOriginInfo().getI6609ReqTransNo() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqTransNo to request");
				}
			}
			if (requestType.getI6609ReqOriginInfo().getI6609ReqSeqNo() != ""
					&& requestType.getI6609ReqOriginInfo().getI6609ReqSeqNo() != null) {
				SOAPElement reqOriginInfoElem5 = reqOriginInfo.addChildElement("i6609-req-seq-no", myNamespace)
						.addTextNode(requestType.getI6609ReqOriginInfo().getI6609ReqSeqNo() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqSeqNo to request");
				}
			}
			if (requestType.getI6609ReqOriginInfo().getI6609ReqOrigTranCd() != ""
					&& requestType.getI6609ReqOriginInfo().getI6609ReqOrigTranCd() != null) {
				SOAPElement reqOriginInfoElem6 = reqOriginInfo.addChildElement("i6609-req-orig-tran-cd", myNamespace)
						.addTextNode(requestType.getI6609ReqOriginInfo().getI6609ReqOrigTranCd() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqOrigTranCd to request");
				}
			}
			if (requestType.getI6609ReqOriginInfo().getI6609ReqOrigTranDt() != ""
					&& requestType.getI6609ReqOriginInfo().getI6609ReqOrigTranDt() != null) {
				SOAPElement reqOriginInfoElem7 = reqOriginInfo.addChildElement("i6609-req-orig-tran-dt", myNamespace)
						.addTextNode(requestType.getI6609ReqOriginInfo().getI6609ReqOrigTranDt() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqOrigTranDt to request");
				}
			}
			if (requestType.getI6609ReqOriginInfo().getI6609ReqOrigTranTm() != ""
					&& requestType.getI6609ReqOriginInfo().getI6609ReqOrigTranTm() != null) {
				SOAPElement reqOriginInfoElem8 = reqOriginInfo.addChildElement("i6609-req-orig-tran-tm", myNamespace)
						.addTextNode(requestType.getI6609ReqOriginInfo().getI6609ReqOrigTranTm() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqOrigTranTm to request");
				}
			}
			if (requestType.getI6609ReqOriginInfo().getI6609ReqOrigTranNo() != ""
					&& requestType.getI6609ReqOriginInfo().getI6609ReqOrigTranNo() != null) {
				SOAPElement reqOriginInfoElem9 = reqOriginInfo.addChildElement("i6609-req-orig-tran-no", myNamespace)
						.addTextNode(requestType.getI6609ReqOriginInfo().getI6609ReqOrigTranNo() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqOrigTranNo to request");
				}
			}
			if (requestType.getI6609ReqOriginInfo().getI6609ReqUniqueId() != ""
					&& requestType.getI6609ReqOriginInfo().getI6609ReqUniqueId() != null) {
				SOAPElement reqOriginInfoElem10 = reqOriginInfo.addChildElement("i6609-req-unique-id", myNamespace)
						.addTextNode(requestType.getI6609ReqOriginInfo().getI6609ReqUniqueId() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqUniqueId to request");
				}
			}
			SOAPElement reqAccInfo = soapBody.addChildElement("i6609-req-acct-info", myNamespace);
			if (requestType.getI6609ReqAcctInfo().getI6609ReqCardType() != ""
					&& requestType.getI6609ReqAcctInfo().getI6609ReqCardType() != null) {
				SOAPElement reqAccInfoElem01 = reqAccInfo.addChildElement("i6609-req-card-type", myNamespace)
						.addTextNode(requestType.getI6609ReqAcctInfo().getI6609ReqCardType() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqCardType to request");
				}
			}
			if (requestType.getI6609ReqAcctInfo().getI6609Req3PGiftType() != ""
					&& requestType.getI6609ReqAcctInfo().getI6609Req3PGiftType() != null) {
				SOAPElement reqAccInfoElem02 = reqAccInfo.addChildElement("i6609-req-3p-gift-type", myNamespace)
						.addTextNode(requestType.getI6609ReqAcctInfo().getI6609Req3PGiftType() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added Req3PGiftType to request");
				}
			}
			if (requestType.getI6609ReqAcctInfo().getI6609ReqAcctFmt() != ""
					&& requestType.getI6609ReqAcctInfo().getI6609ReqAcctFmt() != null) {
				SOAPElement reqAccInfoElem03 = reqAccInfo.addChildElement("i6609-req-acct-fmt", myNamespace)
						.addTextNode(requestType.getI6609ReqAcctInfo().getI6609ReqAcctFmt() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqAcctFmt to request");
				}
			}
			if (requestType.getI6609ReqAcctInfo().getI6609ReqAcctNo() != ""
					&& requestType.getI6609ReqAcctInfo().getI6609ReqAcctNo() != null) {
				SOAPElement reqAccInfoElem04 = reqAccInfo.addChildElement("i6609-req-acct-no", myNamespace)
						.addTextNode(requestType.getI6609ReqAcctInfo().getI6609ReqAcctNo() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqAcctNo to request");
				}
			}
			if (requestType.getI6609ReqAcctInfo().getI6609ReqEntryMode() != ""
					&& requestType.getI6609ReqAcctInfo().getI6609ReqEntryMode() != null) {
				SOAPElement reqAccInfoElem05 = reqAccInfo.addChildElement("i6609-req-entry-mode", myNamespace)
						.addTextNode(requestType.getI6609ReqAcctInfo().getI6609ReqEntryMode() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqEntryMode to request");
				}
			}
			if (requestType.getI6609ReqAcctInfo().getI6609ReqFallbackCd() != ""
					&& requestType.getI6609ReqAcctInfo().getI6609ReqFallbackCd() != null) {
				SOAPElement reqAccInfoElem06 = reqAccInfo.addChildElement("i6609-req-fallback-cd", myNamespace)
						.addTextNode(requestType.getI6609ReqAcctInfo().getI6609ReqFallbackCd() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqFallbackCd to request");
				}
			}
			if (requestType.getI6609ReqAcctInfo().getI6609ReqCardEmvCapable() != ""
					&& requestType.getI6609ReqAcctInfo().getI6609ReqCardEmvCapable() != null) {
				SOAPElement reqAccInfoElem07 = reqAccInfo.addChildElement("i6609-req-card-emv-capable", myNamespace)
						.addTextNode(requestType.getI6609ReqAcctInfo().getI6609ReqCardEmvCapable() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqCardEmvCapable to request");
				}
			}
			if (requestType.getI6609ReqAcctInfo().getI6609ReqEmvCvm() != ""
					&& requestType.getI6609ReqAcctInfo().getI6609ReqEmvCvm() != null) {
				SOAPElement reqAccInfoElem08 = reqAccInfo.addChildElement("i6609-req-emv-cvm", myNamespace)
						.addTextNode(requestType.getI6609ReqAcctInfo().getI6609ReqEmvCvm() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqEmvCvm to request");
				}
			}
			if (requestType.getI6609ReqAcctInfo().getI6609ReqExpDate() != ""
					&& requestType.getI6609ReqAcctInfo().getI6609ReqExpDate() != null) {
				SOAPElement reqAccInfoElem09 = reqAccInfo.addChildElement("i6609-req-exp-date", myNamespace)
						.addTextNode(requestType.getI6609ReqAcctInfo().getI6609ReqExpDate() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqExpDate to request");
				}
			}
			if (requestType.getI6609ReqAcctInfo().getI6609ReqPropAcctType() != ""
					&& requestType.getI6609ReqAcctInfo().getI6609ReqPropAcctType() != null) {
				SOAPElement reqAccInfoElem10 = reqAccInfo.addChildElement("i6609-req-prop-acct-type", myNamespace)
						.addTextNode(requestType.getI6609ReqAcctInfo().getI6609ReqPropAcctType() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqPropAcctType to request");
				}
			}
			if (requestType.getI6609ReqAcctInfo().getI6609ReqCid() != ""
					&& requestType.getI6609ReqAcctInfo().getI6609ReqCid() != null) {
				SOAPElement reqAccInfoElem11 = reqAccInfo.addChildElement("i6609-req-cid", myNamespace)
						.addTextNode(requestType.getI6609ReqAcctInfo().getI6609ReqCid() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqCid to request");
				}
			}
			if (requestType.getI6609ReqAcctInfo().getI6609ReqTrack1Data() != ""
					&& requestType.getI6609ReqAcctInfo().getI6609ReqTrack1Data() != null) {
				SOAPElement reqAccInfoElem12 = reqAccInfo.addChildElement("i6609-req-track1-data", myNamespace)
						.addTextNode(requestType.getI6609ReqAcctInfo().getI6609ReqTrack1Data() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqTrack1Data to request");
				}
			}
			if (requestType.getI6609ReqAcctInfo().getI6609ReqTrack2Data() != ""
					&& requestType.getI6609ReqAcctInfo().getI6609ReqTrack2Data() != null) {
				SOAPElement reqAccInfoElem13 = reqAccInfo.addChildElement("i6609-req-track2-data", myNamespace)
						.addTextNode(requestType.getI6609ReqAcctInfo().getI6609ReqTrack2Data() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqTrack2Data to request");
				}
				
			}
			if (requestType.getI6609ReqAcctInfo().getI6609ReqIccData() != ""
					&& requestType.getI6609ReqAcctInfo().getI6609ReqIccData() != null) {
				SOAPElement reqAccInfoElem15 = reqAccInfo.addChildElement("i6609-req-icc-data", myNamespace)
						.addTextNode(requestType.getI6609ReqAcctInfo().getI6609ReqIccData() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqIccData to request");
				}
			}
			if (requestType.getI6609ReqAcctInfo().getI6609ReqIccCardSeqNo() != ""
					&& requestType.getI6609ReqAcctInfo().getI6609ReqIccCardSeqNo() != null) {
				SOAPElement reqAccInfoElem16 = reqAccInfo.addChildElement("i6609-req-icc-card-seq-no", myNamespace)
						.addTextNode(requestType.getI6609ReqAcctInfo().getI6609ReqIccCardSeqNo() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqIccCardSeqNo to request");
				}

			}
			if (requestType.getI6609ReqAcctInfo().getI6609ReqSerialNbr() != ""
					&& requestType.getI6609ReqAcctInfo().getI6609ReqSerialNbr() != null) {
				SOAPElement reqAccInfoElem17 = reqAccInfo.addChildElement("i6609-req-serial-nbr", myNamespace)
						.addTextNode(requestType.getI6609ReqAcctInfo().getI6609ReqSerialNbr() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqSerialNbr to request");
				}
			}
			if (requestType.getI6609ReqAcctInfo().getI6609ReqPinBlock() != ""
					&& requestType.getI6609ReqAcctInfo().getI6609ReqPinBlock() != null) {
				SOAPElement reqAccInfoElem18 = reqAccInfo.addChildElement("i6609-req-pin-block", myNamespace)
						.addTextNode(requestType.getI6609ReqAcctInfo().getI6609ReqPinBlock() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqPinBlock to request");
				}
			}
			if (requestType.getI6609ReqAmount() != "" && requestType.getI6609ReqAmount() != null) {
				SOAPElement reqAmount = soapBody.addChildElement("i6609-req-amount", myNamespace)
						.addTextNode(requestType.getI6609ReqAmount() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqAmount to request");
				}

			}
			SOAPElement reqAssocInfo = soapBody.addChildElement("i6609-req-assoc-info", myNamespace);
			if (requestType.getI6609ReqAssocInfo().getI6609ReqSellAssocNo1() != ""
					&& requestType.getI6609ReqAssocInfo().getI6609ReqSellAssocNo1() != null) {
				SOAPElement reqAssocInfoElem01 = reqAssocInfo.addChildElement("i6609-req-sell-assoc-no1", myNamespace)
						.addTextNode(requestType.getI6609ReqAssocInfo().getI6609ReqSellAssocNo1() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqSellAssocNo1 to request");
				}

			}
			if (requestType.getI6609ReqAssocInfo().getI6609ReqSellAssocNo2() != ""
					&& requestType.getI6609ReqAssocInfo().getI6609ReqSellAssocNo2() != null) {
				SOAPElement reqAssocInfoElem02 = reqAssocInfo.addChildElement("i6609-req-sell-assoc-no2", myNamespace)
						.addTextNode(requestType.getI6609ReqAssocInfo().getI6609ReqSellAssocNo2() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqSellAssocNo2 to request");
				}

			}
			if (requestType.getI6609ReqAssocInfo().getI6609ReqRingAssocNo() != ""
					&& requestType.getI6609ReqAssocInfo().getI6609ReqRingAssocNo() != null) {
				SOAPElement reqAssocInfoElem03 = reqAssocInfo.addChildElement("i6609-req-ring-assoc-no", myNamespace)
						.addTextNode(requestType.getI6609ReqAssocInfo().getI6609ReqRingAssocNo() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqRingAssocNo to request");
				}

			}
			if (requestType.getI6609ReqDeptNo() != "" && requestType.getI6609ReqDeptNo() != null) {
				SOAPElement reqDeptNo = soapBody.addChildElement("i6609-req-dept-no", myNamespace)
						.addTextNode(requestType.getI6609ReqDeptNo() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqDeptNo to request");
				}

			}
			if (requestType.getI6609ReqPresaleEffDt() != "" && requestType.getI6609ReqPresaleEffDt() != null) {
				SOAPElement reqPresaleEffDt = soapBody.addChildElement("i6609-req-presale-eff-dt", myNamespace)
						.addTextNode(requestType.getI6609ReqPresaleEffDt() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqPresaleEffDt to request");
				}

			}
			if (requestType.getI6609ReqFormOfPmt() != "" && requestType.getI6609ReqFormOfPmt() != null) {
				SOAPElement reqFormPmt = soapBody.addChildElement("i6609-req-form-of-pmt", myNamespace)
						.addTextNode(requestType.getI6609ReqFormOfPmt() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqFormOfPmt to request");
				}

			}
			if ((requestType.getI6609ReqCustInfo().getI6609ReqCustId() != ""
					&& requestType.getI6609ReqCustInfo().getI6609ReqCustId() != null)
					|| (requestType.getI6609ReqCustInfo().getI6609ReqCustState() != ""
							&& requestType.getI6609ReqCustInfo().getI6609ReqCustState() != null)
					|| (requestType.getI6609ReqCustInfo().getI6609ReqFisEntryMeth() != ""
							&& requestType.getI6609ReqCustInfo().getI6609ReqFisEntryMeth() != null)
					|| (requestType.getI6609ReqCustInfo().getI6609ReqFisIdType() != ""
							&& requestType.getI6609ReqCustInfo().getI6609ReqFisIdType() != null)
					|| (requestType.getI6609ReqCustInfo().getI6609ReqFisFlag() != ""
							&& requestType.getI6609ReqCustInfo().getI6609ReqFisFlag() != null)
					|| (requestType.getI6609ReqCustInfo().getI6609ReqAvsAddr() != ""
							&& requestType.getI6609ReqCustInfo().getI6609ReqAvsAddr() != null)
					|| (requestType.getI6609ReqCustInfo().getI6609ReqCustZip() != ""
							&& requestType.getI6609ReqCustInfo().getI6609ReqCustZip() != null)
					|| (requestType.getI6609ReqCustInfo().getI6609ReqIncomeAmt() != ""
							&& requestType.getI6609ReqCustInfo().getI6609ReqIncomeAmt() != null)
					|| (requestType.getI6609ReqCustInfo().getI6609ReqHouseExpType() != ""
							&& requestType.getI6609ReqCustInfo().getI6609ReqHouseExpType() != null)
					|| (requestType.getI6609ReqCustInfo().getI6609ReqHouseExpMmp() != ""
							&& requestType.getI6609ReqCustInfo().getI6609ReqHouseExpMmp() != null)) {
				SOAPElement reqCustInfo = soapBody.addChildElement("i6609-req-cust-info", myNamespace);
				if (requestType.getI6609ReqCustInfo().getI6609ReqCustId() != ""
						&& requestType.getI6609ReqCustInfo().getI6609ReqCustId() != null) {
					SOAPElement reqCustInfoElem01 = reqCustInfo.addChildElement("i6609-req-cust-id", myNamespace)
							.addTextNode(requestType.getI6609ReqCustInfo().getI6609ReqCustId() + "");
					if (activateLoggersForParamsAdded) {
						logger.debug("added ReqCustId to request");
					}

				}
				if (requestType.getI6609ReqCustInfo().getI6609ReqCustState() != ""
						&& requestType.getI6609ReqCustInfo().getI6609ReqCustState() != null) {
					SOAPElement reqCustInfoElem02 = reqCustInfo.addChildElement("i6609-req-cust-state", myNamespace)
							.addTextNode(requestType.getI6609ReqCustInfo().getI6609ReqCustState() + "");
					if (activateLoggersForParamsAdded) {
						logger.debug("added ReqCustState to request");
					}

				}
				if (requestType.getI6609ReqCustInfo().getI6609ReqFisEntryMeth() != ""
						&& requestType.getI6609ReqCustInfo().getI6609ReqFisEntryMeth() != null) {
					SOAPElement reqCustInfoElem03 = reqCustInfo.addChildElement("i6609-req-fis-entry-meth", myNamespace)
							.addTextNode(requestType.getI6609ReqCustInfo().getI6609ReqFisEntryMeth() + "");
					if (activateLoggersForParamsAdded) {
						logger.debug("added ReqFisEntryMeth to request");
					}

				}
				if (requestType.getI6609ReqCustInfo().getI6609ReqFisIdType() != ""
						&& requestType.getI6609ReqCustInfo().getI6609ReqFisIdType() != null) {
					SOAPElement reqCustInfoElem04 = reqCustInfo.addChildElement("i6609-req-fis-id-type", myNamespace)
							.addTextNode(requestType.getI6609ReqCustInfo().getI6609ReqFisIdType() + "");
					if (activateLoggersForParamsAdded) {
						logger.debug("added ReqFisIdType to request");
					}

				}
				if (requestType.getI6609ReqCustInfo().getI6609ReqFisFlag() != ""
						&& requestType.getI6609ReqCustInfo().getI6609ReqFisFlag() != null) {
					SOAPElement reqCustInfoElem05 = reqCustInfo.addChildElement("i6609-req-fis-flag", myNamespace)
							.addTextNode(requestType.getI6609ReqCustInfo().getI6609ReqFisFlag() + "");
					if (activateLoggersForParamsAdded) {
						logger.debug("added ReqFisFlag to request");
					}

				}
				if (requestType.getI6609ReqCustInfo().getI6609ReqAvsAddr() != ""
						&& requestType.getI6609ReqCustInfo().getI6609ReqAvsAddr() != null) {
					SOAPElement reqCustInfoElem06 = reqCustInfo.addChildElement("i6609-req-avs-addr", myNamespace)
							.addTextNode(requestType.getI6609ReqCustInfo().getI6609ReqAvsAddr() + "");
					if (activateLoggersForParamsAdded) {
						logger.debug("added ReqAvsAddr to request");
					}

				}
				if (requestType.getI6609ReqCustInfo().getI6609ReqCustZip() != ""
						&& requestType.getI6609ReqCustInfo().getI6609ReqCustZip() != null) {
					SOAPElement reqCustInfoElem07 = reqCustInfo.addChildElement("i6609-req-cust-zip", myNamespace)
							.addTextNode(requestType.getI6609ReqCustInfo().getI6609ReqCustZip() + "");
					if (activateLoggersForParamsAdded) {
						logger.debug("added ReqCustZip to request");
					}

				}
				if (requestType.getI6609ReqCustInfo().getI6609ReqIncomeAmt() != ""
						&& requestType.getI6609ReqCustInfo().getI6609ReqIncomeAmt() != null) {
					SOAPElement reqCustInfoElem08 = reqCustInfo.addChildElement("i6609-req-income-amt", myNamespace)
							.addTextNode(requestType.getI6609ReqCustInfo().getI6609ReqIncomeAmt() + "");
					if (activateLoggersForParamsAdded) {
						logger.debug("added ReqIncomeAmt to request");
					}
					
				}
				if (requestType.getI6609ReqCustInfo().getI6609ReqHouseExpType() != ""
						&& requestType.getI6609ReqCustInfo().getI6609ReqHouseExpType() != null) {
					SOAPElement reqCustInfoElem09 = reqCustInfo.addChildElement("i6609-req-house-exp-type", myNamespace)
							.addTextNode(requestType.getI6609ReqCustInfo().getI6609ReqHouseExpType() + "");
					if (activateLoggersForParamsAdded) {
						logger.debug("added ReqIncomeAmt to request");
					}
					
				}
				if (requestType.getI6609ReqCustInfo().getI6609ReqHouseExpMmp() != ""
						&& requestType.getI6609ReqCustInfo().getI6609ReqHouseExpMmp() != null) {
					SOAPElement reqCustInfoElem10 = reqCustInfo.addChildElement("i6609-req-house-exp-mmp", myNamespace)
							.addTextNode(requestType.getI6609ReqCustInfo().getI6609ReqHouseExpMmp() + "");
					if (activateLoggersForParamsAdded) {
						logger.debug("added ReqHouseExpMmp to request");
					}
					
				}
			}
			SOAPElement reqAesInfo = soapBody.addChildElement("i6609-req-aes-info", myNamespace);
			if (requestType.getI6609ReqAesInfo().getI6609ReqAesDiv() != ""
					&& requestType.getI6609ReqAesInfo().getI6609ReqAesDiv() != null) {
				SOAPElement reqAesInfoElem01 = reqAesInfo.addChildElement("i6609-req-aes-div", myNamespace)
						.addTextNode(requestType.getI6609ReqAesInfo().getI6609ReqAesDiv() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqAesDiv to request");
				}
				
			}
			if (requestType.getI6609ReqAesInfo().getI6609ReqAesStore() != ""
					&& requestType.getI6609ReqAesInfo().getI6609ReqAesStore() != null) {
				SOAPElement reqAesInfoElem02 = reqAesInfo.addChildElement("i6609-req-aes-store", myNamespace)
						.addTextNode(requestType.getI6609ReqAesInfo().getI6609ReqAesStore() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqAesStore to request");
				}
				
			}
			if (requestType.getI6609ReqAesInfo().getI6609ReqAesVerNo() != ""
					&& requestType.getI6609ReqAesInfo().getI6609ReqAesVerNo() != null) {
				SOAPElement reqAesInfoElem03 = reqAesInfo.addChildElement("i6609-req-aes-ver-no", myNamespace)
						.addTextNode(requestType.getI6609ReqAesInfo().getI6609ReqAesVerNo() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqAesVerNo to request");
				}
				
			}
			if (requestType.getI6609ReqCustIdAesverNo() != "" && requestType.getI6609ReqCustIdAesverNo() != null) {
				SOAPElement reqCustId = soapBody.addChildElement("i6609-req-cust-id-aesver-no", myNamespace)
						.addTextNode(requestType.getI6609ReqCustIdAesverNo() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqCustIdAesverNo to request");
				}
				
			}
			if (requestType.getI6609ReqTransStat() != "" && requestType.getI6609ReqTransStat() != null) {
				SOAPElement reqTransStat = soapBody.addChildElement("i6609-req-trans-stat", myNamespace)
						.addTextNode(requestType.getI6609ReqTransStat() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqTransStat to request");
				}
				
			}
			if (requestType.getI6609ReqTaskId() != "" && requestType.getI6609ReqTaskId() != null) {
				SOAPElement reqTaskId = soapBody.addChildElement("i6609-req-task-id", myNamespace)
						.addTextNode(requestType.getI6609ReqTaskId() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqTaskId to request");
				}
				
			}
			if (requestType.getI6609ReqAmexRefNumb() != "" && requestType.getI6609ReqAmexRefNumb() != null) {
				SOAPElement reqAmex = soapBody.addChildElement("i6609-req-amex-ref-numb", myNamespace)
						.addTextNode(requestType.getI6609ReqAmexRefNumb() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqAmexRefNumb to request");
				}
				
			}
			if ((requestType.getI6609ReqTerminalInfo().getI6609ReqPinEntCap() != ""
					&& requestType.getI6609ReqTerminalInfo().getI6609ReqPinEntCap() != null)
					&& (requestType.getI6609ReqTerminalInfo().getI6609ReqTermEntCap() != ""
							&& requestType.getI6609ReqTerminalInfo().getI6609ReqTermEntCap() != null)
					&& (requestType.getI6609ReqTerminalInfo().getI6609ReqTermDevMdl() != ""
							&& requestType.getI6609ReqTerminalInfo().getI6609ReqTermDevMdl() != null)
					&& (requestType.getI6609ReqTerminalInfo().getI6609ReqTermAppName() != ""
							&& requestType.getI6609ReqTerminalInfo().getI6609ReqTermAppName() != null)
					&& (requestType.getI6609ReqTerminalInfo().getI6609ReqTermAppVer() != ""
							&& requestType.getI6609ReqTerminalInfo().getI6609ReqTermAppVer() != null)) {
				SOAPElement reqTerminalInfo = soapBody.addChildElement("i6609-req-terminal-info", myNamespace);
				SOAPElement reqTerminalInfoElem01 = reqTerminalInfo
						.addChildElement("i6609-req-pin-ent-cap", myNamespace)
						.addTextNode(requestType.getI6609ReqTerminalInfo().getI6609ReqPinEntCap() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqPinEntCap to request");
				}
				
				SOAPElement reqTerminalInfoElem02 = reqTerminalInfo
						.addChildElement("i6609-req-term-ent-cap", myNamespace)
						.addTextNode(requestType.getI6609ReqTerminalInfo().getI6609ReqTermEntCap() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqTermEntCap to request");
				}
				
				SOAPElement reqTerminalInfoElem03 = reqTerminalInfo
						.addChildElement("i6609-req-term-dev-mdl", myNamespace)
						.addTextNode(requestType.getI6609ReqTerminalInfo().getI6609ReqTermDevMdl() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqTermDevMdl to request");
				}
				
				SOAPElement reqTerminalInfoElem04 = reqTerminalInfo
						.addChildElement("i6609-req-term-app-name", myNamespace)
						.addTextNode(requestType.getI6609ReqTerminalInfo().getI6609ReqTermAppName() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqTermAppName to request");
				}
				
				SOAPElement reqTerminalInfoElem05 = reqTerminalInfo
						.addChildElement("i6609-req-term-app-ver", myNamespace)
						.addTextNode(requestType.getI6609ReqTerminalInfo().getI6609ReqTermAppVer() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqTermAppVer to request");
				}
				
			}
			if (requestType.getI6609ReqReservNumber() != "" && requestType.getI6609ReqReservNumber() != null) {
				SOAPElement reqReservNo = soapBody.addChildElement("i6609-req-reserv-number", myNamespace)
						.addTextNode(requestType.getI6609ReqReservNumber() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqReservNumber to request");
				}
				
			}
			if (requestType.getI6609ReqBatchIndicator() != "" && requestType.getI6609ReqBatchIndicator() != null) {
				SOAPElement reqBatchIndi = soapBody.addChildElement("i6609-req-batch-indicator", myNamespace)
						.addTextNode(requestType.getI6609ReqBatchIndicator() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqBatchIndicator to request");
				}
				
			}
			if (requestType.getI6609EciIndicator() != "" && requestType.getI6609EciIndicator() != null) {
				SOAPElement reqEciIndi = soapBody.addChildElement("i6609-eci-indicator", myNamespace)
						.addTextNode(requestType.getI6609EciIndicator() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added EciIndicator to request");
				}
				
			}
			if (requestType.getI66093DSecureCryptogram() != "" && requestType.getI66093DSecureCryptogram() != null) {
				SOAPElement req3dSecureCrypt = soapBody.addChildElement("i6609-3d-secure-cryptogram", myNamespace)
						.addTextNode(requestType.getI66093DSecureCryptogram() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added 3DSecureCryptogram to request");
				}
				
			}
			if (requestType.getI66093DSecCavv() != "" && requestType.getI66093DSecCavv() != null) {
				SOAPElement req3dseccav = soapBody.addChildElement("i6609-3d-sec-cavv", myNamespace)
						.addTextNode(requestType.getI66093DSecCavv() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added 3DSecCavv to request");
				}
				
			}
			if (requestType.getI66093DSecXid() != "" && requestType.getI66093DSecXid() != null) {
				SOAPElement req3dsecxid = soapBody.addChildElement("i6609-3d-sec-xid", myNamespace)
						.addTextNode(requestType.getI66093DSecXid() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added 3DSecXid to request");
				}
				
			}
			if (requestType.getI6609ReqForConvRate() != "" && requestType.getI6609ReqForConvRate() != null) {
				SOAPElement reqForVonv = soapBody.addChildElement("i6609-req-for-conv-rate", myNamespace)
						.addTextNode(requestType.getI6609ReqForConvRate() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqForConvRate to request");
				}
				
			}
			if (requestType.getI6609ReqForCurrCode() != "" && requestType.getI6609ReqForCurrCode() != null) {
				SOAPElement reqForCurrCode = soapBody.addChildElement("i6609-req-for-curr-code", myNamespace)
						.addTextNode(requestType.getI6609ReqForCurrCode() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqForCurrCode to request");
				}
				
			}
			if (requestType.getI6609ReqForCurrAmt() != "" && requestType.getI6609ReqForCurrAmt() != null) {
				SOAPElement reqForCurrAmt = soapBody.addChildElement("i6609-req-for-curr-amt", myNamespace)
						.addTextNode(requestType.getI6609ReqForCurrAmt() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqForCurrAmt to request");
				}
	
			}
			if (requestType.getI6609ReqDccOptionFlag() != "" && requestType.getI6609ReqDccOptionFlag() != null) {
				SOAPElement reqDccOption = soapBody.addChildElement("i6609-req-dcc-option-flag", myNamespace)
						.addTextNode(requestType.getI6609ReqDccOptionFlag() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqDccOptionFlag to request");
				}
				
			}
			if (requestType.getI6609ReqDcc2PassFlag() != "" && requestType.getI6609ReqDcc2PassFlag() != null) {
				SOAPElement reqdcc2Pass = soapBody.addChildElement("i6609-req-dcc-2-pass-flag", myNamespace)
						.addTextNode(requestType.getI6609ReqDcc2PassFlag() + "");
				if (activateLoggersForParamsAdded) {
					logger.debug("added ReqDcc2PassFlag to request");
				}
				
			}
		} catch (SOAPException soape) {
		}
	}

	private SOAPMessage createSOAPRequest(String uri, XSCMRequestType irnRequest, String password, File requestFile,
			File responseFile, Integer count) {
		try {
			MessageFactory messageFactory = MessageFactory.newInstance();
			SOAPMessage soapMessage = messageFactory.createMessage();
			logger.debug("creating soap envelope");
			createSoapEnvelope(soapMessage, uri, irnRequest, requestFile, responseFile, count);
			MimeHeaders headers = soapMessage.getMimeHeaders();
			headers.addHeader("SOAPAction", uri);
			SOAPHeader header = soapMessage.getSOAPHeader();
			QName order = new QName("http://www.macys.com/enterprise_services", "requestor_info", "ns2");
			SOAPHeaderElement orderHeader = header.addHeaderElement(order);
			if (irnRequest.getVersion() != "" && irnRequest.getVersion() != null) {
				orderHeader.addChildElement("version").addTextNode(irnRequest.getVersion() + "");
			} else {
				orderHeader.addChildElement("version").addTextNode("01.000.0000");
			}
			orderHeader.addChildElement("client_id").addTextNode(irnRequest.getClientId() + "");
			if (irnRequest.getSubclientId() != "" && irnRequest.getSubclientId() != null) {
				orderHeader.addChildElement("subclient_id").addTextNode(irnRequest.getSubclientId() + "");
			}
			soapMessage.saveChanges();
			return soapMessage;
		} catch (Exception e) {
			return null;
		}
	}
}