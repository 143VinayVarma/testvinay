package stepdefinitions;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import com.sun.rowset.internal.Row;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import javafx.scene.control.Cell;
import utility.TestSuiteUtil;
import utility.WorkBookUtil;
import utility.XSCM6609OP2Client;
import utility.XSCMRequestType;
import utility.XSCMResponseType;

public class StepDefinition {
	private static ArrayList<File> requestList = new ArrayList<File>();
	private static ArrayList<File> responseList = new ArrayList<File>();
	private static LinkedHashMap<File, File> requestResponseMap = new LinkedHashMap<File, File>();
	static Logger logger = Logger.getLogger(StepDefinition.class);

	public static String soapEndpointUrl, uri, password;
	int rowcount, sheetcnt, processcount, passcount, failcount;
	Long startTime;
	Workbook wb1, wb2;
	String[] sheetvaluesresp1 = new String[100];
	String[] sheetvaluesresp2 = new String[100];
	static boolean activateLoggersForStepDefinition = TestSuiteUtil.getLoggerStatusForStepDefinition();

	static {
		if (TestSuiteUtil.getFileList() == true) {
			requestList = TestSuiteUtil.retrieveFileList("request_library");
			responseList = TestSuiteUtil.retrieveFileList("response_library");
			requestResponseMap = TestSuiteUtil.retrieveRequestResponseMap(requestList, responseList);
		} else {
			requestList.add(new File(TestSuiteUtil.getInputRequestFile()));
			responseList.add(new File(TestSuiteUtil.getOutputResponseFile()));
			requestResponseMap = TestSuiteUtil.retrieveRequestResponseMap(requestList, responseList);
		}
	}

	@Given("^the end point \"([^\"]*)\"$")
	public void the_end_point(String arg1) throws Throwable {
		startTime = System.nanoTime();
		soapEndpointUrl = TestSuiteUtil.getSoapEndPointUrl();
		uri = TestSuiteUtil.getUri();
		password = TestSuiteUtil.getPassword();
		requestResponseMap.forEach((k, v) -> {
			try {
				if (activateLoggersForStepDefinition) {
					logger.debug(
							"*********************************************************************************************************");
					logger.debug("***request file: " + k.toString() + "------response file: " + v.toString() + "***");
				} else {
					System.out.println(
							"*********************************************************************************************************");
					System.out.println(
							"***request file: " + k.toString() + "------response file: " + v.toString() + "***");
				}
				invoke_SoapUI_fn(k, v);
			} catch (Throwable e) {
				logger.error("exception occurred", e);
			}
		});
	}

	@SuppressWarnings("null")
	@Then("^invoke SoapUI$")
	public void invoke_SoapUI() throws Throwable {
		ArrayList<File> responses = new ArrayList<File>();
		responses = responseList;
		Cell cell;
		for (int i = 0; i < responses.size(); i++) {
			processcount = 0;
			passcount = 0;
			failcount = 0;
			String temporaryfileName = responses.get(i).toString().substring(17);
			String[] fileLabelArray = temporaryfileName.toString().split("_");
			wb1 = WorkbookFactory.create(new FileInputStream(responses.get(i)));
			wb2 = WorkbookFactory.create(new FileInputStream("result_library/" + fileLabelArray[0] + "_"
					+ fileLabelArray[1] + "_" + fileLabelArray[2] + "_vtest.xls"));
			for (int k = 0; k < (1); k++) {
				sheetvaluesresp1[k] = wb1.getSheetName(k);
				rowcount = wb1.getSheet(sheetvaluesresp1[k]).getLastRowNum();
				sheetvaluesresp2[k] = wb1.getSheetName(k);
				for (int l = 1; l <= rowcount; l++) {
					// Assertion 1 : Validation of "Result" tag
					try {
						String str1 = String
								.valueOf((wb1.getSheet(sheetvaluesresp1[k]).getRow(l).getCell(1).toString()));
						String str2 = String
								.valueOf((wb2.getSheet(sheetvaluesresp2[k]).getRow(l).getCell(0).toString()));
						cell = null;
						cell = wb2.getSheet(sheetvaluesresp2[k]).getRow(l).createCell(1);
						if (str1.equalsIgnoreCase(str2)) {
							cell.setCellValue("Valid");
							passcount++;
						} else {
							cell.setCellValue("In-Valid");
							failcount++;
						}
					} catch (Exception mex) {
						logger.error("exception occurred while asserting result tag", mex);
					}
					// Assertion 2 : Validation of "Auth CD" tag
					try {
						String str2 = String
								.valueOf((wb2.getSheet(sheetvaluesresp2[k]).getRow(l).getCell(10).toString()));
						cell = null;
						cell = wb2.getSheet(sheetvaluesresp2[k]).getRow(l).createCell(11);
						if (!("null".equalsIgnoreCase(str2)) && !("".equalsIgnoreCase(str2))) {
							cell.setCellValue("Valid Result, ignoring value");
						} else if ("null".equalsIgnoreCase(str2)) {
							cell.setCellValue(" ");
						} else if ("SYSERR".equalsIgnoreCase(str2)) {
							cell.setCellValue("In-Valid");
						} else {
							cell.setCellValue(" ");
						}
					} catch (Exception mex) {
						logger.error("exception occurred while asserting Auth cd", mex);
					}
					// Assertion 3 : Validation of "Account Number" tag
					try {
						String str1 = String
								.valueOf((wb1.getSheet(sheetvaluesresp1[k]).getRow(l).getCell(15).toString()));
						String str2 = String
								.valueOf((wb2.getSheet(sheetvaluesresp2[k]).getRow(l).getCell(12).toString()));
						cell = null;
						cell = wb2.getSheet(sheetvaluesresp2[k]).getRow(l).createCell(13);
						if (str1.equalsIgnoreCase(str2)) {
							cell.setCellValue("Valid Result, ignoring value");
						} else {
							cell.setCellValue("In-Valid");
						}
					} catch (Exception mex) {
						logger.error("exception occurred while asserting account number", mex);
					}
					// Assertion 4 : Validation of "Gift Bal Rem" tag
					try {
						String str2 = String
								.valueOf((wb2.getSheet(sheetvaluesresp2[k]).getRow(l).getCell(14).toString()));
						cell = null;
						cell = wb2.getSheet(sheetvaluesresp2[k]).getRow(l).createCell(15);
						if (!("null".equalsIgnoreCase(str2)) && !("".equalsIgnoreCase(str2))) {
							cell.setCellValue("Valid Result, ignoring value");
						} else if ("null".equalsIgnoreCase(str2)) {
							cell.setCellValue(" ");
						} else {
							cell.setCellValue(" ");
						}
					} catch (Exception mex) {
						logger.error("exception occurred while asserting gift bal rem", mex);
					}
					// Assertion 5 : Validation of "Gift Crd Amt app" tag
					try {
						String str2 = String
								.valueOf((wb2.getSheet(sheetvaluesresp2[k]).getRow(l).getCell(16).toString()));
						cell = null;
						cell = wb2.getSheet(sheetvaluesresp2[k]).getRow(l).createCell(17);
						if (!("null".equalsIgnoreCase(str2)) && !("".equalsIgnoreCase(str2))) {
							cell.setCellValue("Valid Result, ignoring value");
						} else if ("null".equalsIgnoreCase(str2)) {
							cell.setCellValue(" ");
						} else {
							cell.setCellValue(" ");
						}
					} catch (Exception mex) {
						logger.error("exception occurred gift card amount app", mex);
					}
					// Assertion 6 : Validation of "Amex ref numb" tag
					try {
						String str2 = String
								.valueOf((wb2.getSheet(sheetvaluesresp2[k]).getRow(l).getCell(18).toString()));
						cell = null;
						cell = wb2.getSheet(sheetvaluesresp2[k]).getRow(l).createCell(19);
						if (!("null".equalsIgnoreCase(str2)) && !("".equalsIgnoreCase(str2))) {
							cell.setCellValue("Valid Result, ignoring value");
						} else if ("null".equalsIgnoreCase(str2)) {
							cell.setCellValue(" ");
						} else {
							cell.setCellValue(" ");
						}
					} catch (Exception mex) {
						logger.error("exception occurred while asserting amex ref num", mex);
					}
					// Assertion 7 : Validation of "AVS Resp CD" tag
					try {
						String str1 = String
								.valueOf((wb1.getSheet(sheetvaluesresp1[k]).getRow(l).getCell(21).toString()));
						String str2 = String
								.valueOf((wb2.getSheet(sheetvaluesresp2[k]).getRow(l).getCell(20).toString()));
						cell = null;
						cell = wb2.getSheet(sheetvaluesresp2[k]).getRow(l).createCell(21);
						if (str1.equalsIgnoreCase(str2)) {
							cell.setCellValue("Valid");
						} else if ("null".equalsIgnoreCase(str2)) {
							cell.setCellValue(" ");
						} else {
							cell.setCellValue("In-Valid");
						}
					} catch (Exception mex) {
						logger.error("exception occurred while asserting resp cd", mex);
					}
					// Assertion 8 : Validation of "3P ID" tag
					try {
						String str2 = String
								.valueOf((wb2.getSheet(sheetvaluesresp2[k]).getRow(l).getCell(22).toString()));
						cell = null;
						cell = wb2.getSheet(sheetvaluesresp2[k]).getRow(l).createCell(23);
						if (!("null".equalsIgnoreCase(str2)) && !("".equalsIgnoreCase(str2))) {
							cell.setCellValue("Valid Result, ignoring value");
						} else if ("null".equalsIgnoreCase(str2)) {
							cell.setCellValue(" ");
						} else {
							cell.setCellValue(" ");
						}
					} catch (Exception mex) {
						logger.error("exception occurred while asserting 3p id", mex);
					}
					// Assertion 9 : Validation of "Return C" tag
					try {

						String str1 = String
								.valueOf((wb1.getSheet(sheetvaluesresp1[k]).getRow(l).getCell(25).toString() + ""));
						String str2 = String
								.valueOf((wb2.getSheet(sheetvaluesresp2[k]).getRow(l).getCell(24).toString() + ""));
						cell = null;
						cell = wb2.getSheet(sheetvaluesresp2[k]).getRow(l).createCell(25);
						if (str2 != null) {
							cell.setCellValue(" ");
						}
						if (str1.equalsIgnoreCase(str2)) {
							cell.setCellValue("Valid");
						} else if ("null".equalsIgnoreCase(str2)) {
							cell.setCellValue(" ");
						} else {
							cell.setCellValue("In-Valid");
						}

					} catch (Exception mex) {
						logger.error("exception occurred while asserting return c", mex);
					}
					// Assertion 10 : Validation of "Act C PRI" tag
					try {
						String str1 = String
								.valueOf((wb1.getSheet(sheetvaluesresp1[k]).getRow(l).getCell(30).toString()));
						String str2 = String
								.valueOf((wb2.getSheet(sheetvaluesresp2[k]).getRow(l).getCell(26).toString()));
						cell = null;
						cell = wb2.getSheet(sheetvaluesresp2[k]).getRow(l).createCell(27);
						if (str1.equalsIgnoreCase(str2)) {
							cell.setCellValue("Valid");
						} else {
							cell.setCellValue("In-Valid");
						}
					} catch (Exception mex) {
						logger.error("exception occurred while asserting c-pri", mex);
					}
					// Assertion 11 : Validation of "3P Status Code" tag
					try {
						String str1 = String
								.valueOf((wb1.getSheet(sheetvaluesresp1[k]).getRow(l).getCell(42).toString() + ""));
						String str2 = String
								.valueOf((wb2.getSheet(sheetvaluesresp2[k]).getRow(l).getCell(29).toString() + ""));
						cell = null;
						cell = wb2.getSheet(sheetvaluesresp2[k]).getRow(l).createCell(30);
						if (str2 != null) {
							cell.setCellValue(" ");
						}
						if (str1.equalsIgnoreCase(str2)) {
							cell.setCellValue("Valid");
						} else if ("null".equalsIgnoreCase(str2)) {
							cell.setCellValue(" ");
						} else {
							cell.setCellValue("In-Valid");
						}
						// }
					} catch (Exception mex) {
						logger.error("exception occurred while asserting 3ps", mex);
					}
					// Assertion 12 : Validation of "3P Approval code" tag
					try {
						String str2 = String
								.valueOf((wb2.getSheet(sheetvaluesresp2[k]).getRow(l).getCell(31).toString()));
						cell = null;
						cell = wb2.getSheet(sheetvaluesresp2[k]).getRow(l).createCell(32);
						if (str2 != null) {
							cell.setCellValue(" ");
						} else if ("SYSERR".equalsIgnoreCase(str2)) {
							cell.setCellValue("In-Valid");
						} else if (!("null".equalsIgnoreCase(str2)) && !("".equalsIgnoreCase(str2))) {
							cell.setCellValue("Valid Result, ignoring value");
						} else if ("null".equalsIgnoreCase(str2)) {
							cell.setCellValue(" ");
						} else {
							cell.setCellValue(" ");
						}
					} catch (Exception mex) {
						logger.error("exception occurred while asserting 3p approval code", mex);
					}
					// Assertion 13 : Validation of "Reg Status Code" tag
					try {
						if (wb1.getSheet(sheetvaluesresp1[k]).getRow(l).getCell(46).getCellType() == 0
								|| wb2.getSheet(sheetvaluesresp2[k]).getRow(l).getCell(33).getCellType() == 0) {
							int str1 = (int) Double.parseDouble(
									wb1.getSheet(sheetvaluesresp1[k]).getRow(l).getCell(46).toString() + "");
							int str2 = (int) Double.parseDouble(
									wb2.getSheet(sheetvaluesresp2[k]).getRow(l).getCell(33).toString() + "");
							cell = null;
							cell = wb2.getSheet(sheetvaluesresp2[k]).getRow(l).createCell(34);
							if (str1 == str2) {
								cell.setCellValue("Valid");
							} else {
								cell.setCellValue("In-Valid");
							}
						} else {
							String str1 = String
									.valueOf((wb1.getSheet(sheetvaluesresp1[k]).getRow(l).getCell(46).toString() + ""));
							String str2 = String
									.valueOf((wb2.getSheet(sheetvaluesresp2[k]).getRow(l).getCell(33).toString() + ""));
							cell = null;
							cell = wb2.getSheet(sheetvaluesresp2[k]).getRow(l).createCell(34);
							if (str1.equalsIgnoreCase(str2)) {
								cell.setCellValue("Valid");
							} else if (("null".equalsIgnoreCase(str2)) || (" ".equalsIgnoreCase(str2))) {
								cell.setCellValue("");
							} else {
								cell.setCellValue("In-Valid");
							}
						}
					} catch (Exception mex) {
						logger.error("exception occurred while asserting reg status code", mex);
					}
					// Assertion 14 : Validation of "RSP AVS Indicator" tag
					try {
						String str1 = String
								.valueOf((wb1.getSheet(sheetvaluesresp1[k]).getRow(l).getCell(49).toString()));
						String str2 = String
								.valueOf((wb2.getSheet(sheetvaluesresp2[k]).getRow(l).getCell(35).toString()));
						cell = null;
						cell = wb2.getSheet(sheetvaluesresp2[k]).getRow(l).createCell(36);
						if (str1.equalsIgnoreCase(str2)) {
							cell.setCellValue("Valid");
						} else if (("null".equalsIgnoreCase(str2))) {
							cell.setCellValue("");
						} else if (" ".equalsIgnoreCase(str2)) {
							cell.setCellValue(" ");
						} else {
							cell.setCellValue("In-Valid");
						}
					} catch (Exception mex) {
						logger.error("exception occurredwhile asserting avs", mex);
					}
					// Assertion 15 : Validation of "Discover data" tag
					try {
						String str1 = String
								.valueOf((wb1.getSheet(sheetvaluesresp1[k]).getRow(l).getCell(50).toString()));
						String str2 = String
								.valueOf((wb2.getSheet(sheetvaluesresp2[k]).getRow(l).getCell(37).toString()));
						cell = null;
						cell = wb2.getSheet(sheetvaluesresp2[k]).getRow(l).createCell(38);
						if (str1.equalsIgnoreCase(str2)) {
							cell.setCellValue("Valid");
						} else if (("null".equalsIgnoreCase(str2))) {
							cell.setCellValue("");
						} else if (" ".equalsIgnoreCase(str2)) {
							cell.setCellValue(" ");
						} else {
							cell.setCellValue("In-Valid");
						}
					} catch (Exception mex) {
						logger.error("exception occurredwhile asserting discover data", mex);
					}
				}
				processcount += rowcount;
			}
			try {
				FileOutputStream out = new FileOutputStream(new File("result_library/" + fileLabelArray[0] + "_"
						+ fileLabelArray[1] + "_" + fileLabelArray[2] + "_vtest.xls"));
				wb2.write(out);
				out.close();
			} catch (Exception e) {
				logger.error("exception occurred", e);
			}
			Long endTime = System.nanoTime();
			Long totalTime = endTime - startTime;
			double seconds1 = (double) totalTime / 1000000000.0;
			long microseconds = totalTime / 1000;
			long miliseconds = microseconds / 1000;
			long seconds = miliseconds / 1000;
			long minutes = seconds / 60;
			long hours = minutes / 60;
			System.out.println("\n");
			String processedRequest = fileLabelArray[0] + "_" + fileLabelArray[1] + "_" + fileLabelArray[2]
					+ " request sample";
			System.out.println("processed " + processedRequest);
			System.out.println("Total number of request processed:" + processcount);
			System.out.println(
					"total time taken for execution in seconds: " + hours + "h" + minutes + "m" + seconds1 + "s");
			StringBuilder sb = new StringBuilder();
			sb.append("Total number of request processed::   " + processcount + "\n");
			sb.append("Total time taken for execution in seconds::   " + hours + "h" + minutes + "m" + seconds1 + "s.");
			String formattedSeconds = String.valueOf(seconds).substring(0, 2);
			String time = hours + "h" + minutes + "m" + formattedSeconds + "s";
			String vantivCode = fileLabelArray[1] + "_" + fileLabelArray[2];
			sendEmail(sb.toString(), vantivCode, "result_library/" + fileLabelArray[0] + "_" + fileLabelArray[1] + "_"
					+ fileLabelArray[2] + "_vtest.xls", processcount, time, processedRequest);
		}
	}

	public void invoke_SoapUI_fn(File requestFile, File responseFile) throws Throwable {
		startTime = System.nanoTime();
		HSSFWorkbook workbook = new HSSFWorkbook();
		int rownum = 0;
		Row row;
		Cell cell;
		XSCM6609OP2Client xscm6609op2Client = new XSCM6609OP2Client();
		WorkBookUtil workBookUtil = new WorkBookUtil();
		Workbook requestWorkBook = WorkbookFactory.create(new FileInputStream(requestFile));
		Map<String, List<XSCMRequestType>> requestTypeMap = new LinkedHashMap<>();
		requestTypeMap = workBookUtil.prepareSheetData(requestWorkBook);
		Set<String> sheetNameSet = requestTypeMap.keySet();
		for (String sheetName : sheetNameSet) {
			rownum = 0;
			HSSFSheet sheet = workbook.createSheet(sheetName);
			List<XSCMRequestType> requestTypeList = requestTypeMap.get(sheetName);
			row = sheet.createRow(rownum++);
			String[] headerStringArray = { "o6609RspResult", "Validation-Result", "o6609RspDivision", "o6609RspStoreNo",
					"o6609RspTermNo", "o6609RspTransNo", "o6609RspSeqNo", "o6609RspOrigTranDt", "o6609RspOrigTranTm",
					"o6609RspOrigTranNo", "o6609RspAuthCd", "Validation-AuthCD", "o6609RspAcctNo",
					"Validation-AccountNo", "o6609RspGftcrdBalRem", "Validation-GftBal", "o6609RspGftcrdAmtApp", "Validation-GftCrdAmtApp", 
					"o6609RspAmexRefNumb", "Validation-AmexRefNum","o6609AvsRespCd", "Validation-AvsRespCd", "o66093PId", "Validation-3PId", "o6609ReturnC", "Validation-ReturnC",
					"o6609ActCPri", "Validation-ActCPri", "o6609ActCSec", "o66093PStatusCode",
					"Validation-3PStatusCode", "o66093PApprovalCode", "Validation-3PApprovalCode", "o6609RegStatusCode",
					"Validation-RegStatusCode", "o6609RspAvsIndicator", "Validation-RspAvsIndicator",
					"o6609RspDiscoverData", "Validation-Discover" };
			@SuppressWarnings("unchecked")
			List<String> responseHeader = Arrays.asList(headerStringArray);

			for (int key1 = 0; key1 < responseHeader.size(); key1++) {
				cell = row.createCell(key1);
				cell.setCellValue(responseHeader.get(key1));
			}
			int cnts = 1;
			for (XSCMRequestType requestType : requestTypeList) {
				System.out.println("Processing request: " + cnts++);
				Integer count = cnts - 1;
				try {
					XSCMResponseType xscmresponseType = xscm6609op2Client.callWebService(soapEndpointUrl, requestType,
							uri, password, requestFile, responseFile, count);
					String[] data1 = { xscmresponseType.getO6609RspResult() + "", "",
							xscmresponseType.getO6609RspOriginInfo().getO6609RspDivision() + "",
							xscmresponseType.getO6609RspOriginInfo().getO6609RspStoreNo() + "",
							xscmresponseType.getO6609RspOriginInfo().getO6609RspTermNo() + "",
							xscmresponseType.getO6609RspOriginInfo().getO6609RspTransNo() + "",
							xscmresponseType.getO6609RspOriginInfo().getO6609RspSeqNo() + "",
							xscmresponseType.getO6609RspOriginInfo().getO6609RspOrigTranDt() + "",
							xscmresponseType.getO6609RspOriginInfo().getO6609RspOrigTranTm() + "",
							xscmresponseType.getO6609RspOriginInfo().getO6609RspOrigTranNo() + "",
							xscmresponseType.getO6609RspAuthCd() + "", "",
							xscmresponseType.getO6609RspAcctInfo().getO6609RspAcctNo() + "", "",
							xscmresponseType.getO6609RspAcctInfo().getO6609RspGftcrdBalRem() + "", "",
							xscmresponseType.getO6609RspAcctInfo().getO6609RspGftcrdAmtApp() + "", "",
							xscmresponseType.getO6609RspAmexRefNumb() + "", "", 
							xscmresponseType.getO6609AvsRespCd() + "", "",
							xscmresponseType.getO6609RspDetermination().getO66093PId() + "", "",
							xscmresponseType.getO6609RspDetermination().getO6609CompletionStatus().getO6609ReturnC() + "",
							"",
							xscmresponseType.getO6609RspDetermination().getO6609RspPosActionCode().getO6609ActCPri() + "",
							"",
							xscmresponseType.getO6609RspDetermination().getO6609RspPosActionCode().getO6609ActCSec() + "",
							xscmresponseType.getO6609RspDetermination().getO6609Rsp3PResponse().getO66093PStatusCode() + "",
							"",
							xscmresponseType.getO6609RspDetermination().getO6609Rsp3PResponse().getO66093PApprovalCode()
									+ "",
							"",
							xscmresponseType.getO6609RspDetermination().getO6609RspDebitResponse().getO6609RegStatusCode()
									+ "",
							"", xscmresponseType.getO6609RspAvsIndicator() + "", "",
							xscmresponseType.getO6609RspDiscoverData() + "", "" };
					@SuppressWarnings({ "unchecked", "unused" })
					List<XSCMResponseType> s1 = Arrays.asList(data1);
					row = sheet.createRow(rownum++);
					for (int key1 = 0; key1 < responseHeader.size(); key1++) {
						cell = row.createCell(key1);
						cell.setCellValue(data1[key1]);
					}
				} catch (Exception e) {
					logger.error("exception occurred", e);
				}
			}
			try {
				String temporaryfileName = responseFile.toString().substring(16);
				String[] fileLabelArray = temporaryfileName.toString().split("_");
				FileOutputStream out = new FileOutputStream(new File("result_library/" + fileLabelArray[0] + "_"
						+ fileLabelArray[1] + "_" + fileLabelArray[2] + "_vtest.xls"));
				workbook.write(out);
				out.close();
				
			} catch (Exception e) {
				logger.error("exception occurred", e);
			}
		}
	}

	public void sendEmail(String bodyText, String vantivCode, String resultFilePath, Integer totalRequestsProcessed,
			String time, String processedRequest) throws MessagingException, IOException {
		String sender = TestSuiteUtil.getSender();
		String host = TestSuiteUtil.getHost();
		String filename = resultFilePath;
		String smtpFormat = TestSuiteUtil.getSmtpFormat();
		String recipientList = TestSuiteUtil.getRecipeintList();
		String carbonCopyList = TestSuiteUtil.getCarbonCopyList();
		String subject = "Test Execution Summary of sample requests - " + vantivCode;
		Properties properties = System.getProperties();
		properties.setProperty(smtpFormat, host);
		Session session = Session.getDefaultInstance(properties);
		try {
			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress(sender));
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipientList));
			message.setRecipients(Message.RecipientType.CC, InternetAddress.parse(carbonCopyList));
			message.setSubject(subject);
			BodyPart messageBodyPart1 = new MimeBodyPart();
			String sb1 = "<head>\n" + "<style>\n" + "#header{\n" + "height: 100px;\n" + "width: 100%;\n"
					+ "background-color:dimgrey;\n" + "}\n" + "#messageBody{\n" + "height: 400px;\n" + "width: 100%;\n"
					+ "background-color:white;\n" + "}\n" + "#footer{\n" + "height: 200px;\n" + "width: 100%;\n"
					+ "background-color:white;\n" + "}\n" + "</style>\n" + "</head>\n" + "<body>\n"
					+ "<div id=\"header\">\n"
					+ "<h1><center><font face=\"verdana\" size=\"5\" color=\"white\">Test Execution Summary</font></center></h1>\n"
					+ "</div>\n" + "<div id=\"messageBody\">\n" + "<table>\n" + "<tr>\n"
					+ "<td><font face=\"verdana\" size=\"4\">Test Execution performed for </font></td>\n"
					+ "<td><font face=\"verdana\" size=\"4\">" + processedRequest + "</font></td>\n" + "</tr>\n"
					+ "<tr>\n" + "<td></td>\n" + "<td></td>\n" + "</tr>\n" + "<tr>\n"
					+ "<td><font face=\"verdana\" size=\"4\">Total number of request processed</font></td>\n"
					+ "<td><font face=\"verdana\" size=\"4\">" + totalRequestsProcessed + "</font></td>\n" + "</tr>\n"
					+ "<tr>\n" + "<td><font face=\"verdana\" size=\"4\">Total time taken for execution</font></td>\n"
					+ "<td><font face=\"verdana\" size=\"4\">" + time + "</font></td>\n" + "</tr>\n" + "<tr>\n"
					+ "<td></td>\n" + "<td></td>\n" + "</tr>\n" + "<tr>\n" + "<td></td>\n" + "<td></td>\n" + "</tr>\n"
					+ "<tr>\n" + "<td></td>\n" + "<td></td>\n" + "</tr>\n" + "<tr>\n" + "<td></td>\n" + "<td></td>\n"
					+ "</tr>\n" + "<tr>\n"
					+ "<td><font face=\"verdana\" size=\"4\">Total Number of test cases passed</font></td>\n"
					+ "<td><font face=\"verdana\" size=\"4\">" + passcount + "</font></td>\n" + "</tr>\n" + "<tr>\n"
					+ "<td><font face=\"verdana\" size=\"4\">Total Number of test cases failed</font></td>\n"
					+ "<td><font face=\"verdana\" size=\"4\">" + failcount + "</font></td>\n" + "</tr>\n" + "<tr>\n"
					+ "<td></td>\n" + "<td></td>\n" + "</tr>\n" + "<tr>\n" + "<td></td>\n" + "<td></td>\n" + "</tr>\n"
					+ "<tr>\n" + "<td></td>\n" + "<td></td>\n" + "</tr>\n" + "<tr>\n" + "<td></td>\n" + "<td></td>\n"
					+ "</tr>\n" + "<tr>\n"
					+ "<td><font face=\"verdana\" size=\"4\">Attached the test result spread sheet.</font></td>\n"
					+ "<td></td>\n" + "</tr>\n" + "<tr>\n" + "<td></td>\n" + "<td></td>\n" + "</tr>\n" + "<tr>\n"
					+ "<td></td>\n" + "<td></td>\n" + "</tr>\n" + "<tr>\n"
					+ "<td><font face=\"verdana\" size=\"4\">Regards</font></td>\n" + "<td></td>\n" + "</tr>\n"
					+ "<tr>\n" + "<td><font face=\"verdana\" size=\"4\">-Vinay</font></td>\n" + "<td></td>\n"
					+ "</tr>\n" + "</table>\n" + "</div>\n" + "<div id=\"footer\">" + "</div>\n" + "</body>\n";
			messageBodyPart1.setContent(sb1, "text/html; charset=utf-8");
			BodyPart messageBodyPart2 = new MimeBodyPart();
			DataSource source = new FileDataSource(filename);
			messageBodyPart2.setDataHandler(new DataHandler(source));
			messageBodyPart2.setFileName(source.getName());
			Multipart multipartObject = new MimeMultipart();
			multipartObject.addBodyPart(messageBodyPart1);
			multipartObject.addBodyPart(messageBodyPart2);
			message.setContent(multipartObject);
			Transport.send(message);
			if (activateLoggersForStepDefinition) {
				logger.debug("Test Mail successfully sent");
			} else {
				System.out.println("Test Mail successfully sent");
			}
		} catch (MessagingException mex) {
			logger.error("Messaging exception occurred", mex);
		}
	}
}