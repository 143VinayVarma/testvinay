package Section08;

import java.util.ArrayList;
import java.util.List;

public class GradeBO {
	
private List<Integer> gradeList=new ArrayList<Integer>();
	
	
	public List<Integer> getGradeList() {
		return gradeList;
	}


	public void setGradeList(List<Integer> gradeList) {
		this.gradeList = gradeList;
	}


	//This method should add the gradePoints secured by the students which passed as the argument in to the List
	public void addGradeDetails(int gradePoint)
	{
		getGradeList().add(gradePoint);
		
	}
	
	
	/* This method should return the GPA of all grades scored in the semester 
	 * 
	 * 
	 * Grade	S	A	B	C	D	E
  Grade Point	10	9	8	7	6	5

	GPA  can be calculated based on the following formula
	GPA= (gradePoint1 * creditPoint1) + (gradePoint2 * creditPoint2) + ... + (gradePointN * creditPointN)/(size of List * 3)
	
	For Example:
	 if the list contains the following marks [9,10,8,5]
	 GPA = ((9 + 10 + 8 + 5) * 3) / (4 * 3)= 8.0

	 */
	public double getGPAScored()
	{
			double gpa=0;
			if(gradeList.size()>0)
			{ 
				gpa=0;
			for (int i = 0; i < gradeList.size(); i++) {
			gpa=gpa+gradeList.get(i);
			}
			gpa=gpa/gradeList.size();
			
		}
			
			//type your logic here
			return gpa;
}}
