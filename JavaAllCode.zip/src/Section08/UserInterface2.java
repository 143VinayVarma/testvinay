package Section08;

import java.util.Scanner;

public class UserInterface2 {

	public static void main(String[] args) 
	{
		GradeBO b=new GradeBO();
		Scanner sc =new Scanner(System.in);
		//Fill the UI code
		
		
	boolean f=false;
		while(!f) {
			System.out.println("1. Add GradePoint");
			System.out.println("2. Calculate GPA");
			System.out.println("3. Exit");
			System.out.println("Enter your choice");
			int choice=sc.nextInt();
		if(choice==1)
		{
			System.out.println("Enter the gradePoint scored");
			int marks=sc.nextInt();
			
			b.addGradeDetails(marks);
			
		}
		else if(choice==2)
		{
			
			if(b.getGPAScored()!=0) {
				System.out.println("GPA Scored");
				System.out.println(b.getGPAScored());
				}
			else
					System.out.println("No GradePoints available");
				
			}
		else {
			System.out.println("Thank you for using the Application");
			break;
		}}
sc.close();
	}	//Type your code here
	}

