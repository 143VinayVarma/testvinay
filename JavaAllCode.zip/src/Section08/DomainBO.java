package Section08;


import java.util.Map;
import java.util.TreeMap;

public class DomainBO {
	
	private Map<String,String> domainMap=new TreeMap<String,String>();;
	
	
	public Map<String,String> getDomainMap() {
		return domainMap;
	}


	public void setDomainMap(Map<String,String> domainMap) {
		this.domainMap = domainMap;
	}


	//This method should add the domainName as key and their ipAddress as value into a Map
	public void addDNSDetails  (String domainName,String ipAddress)
	{	
		//type your logic here
	getDomainMap().put(domainName,ipAddress);
	}
	
	/*
	 * This method should return the domain name for the specific ipAddress which is passed as the argument. 
	 * For example: If the map contains the key and value as:
	 * www.yahoo.net	205.16.214.15
	   www.gmail.net	195.116.254.154
	   www.tech.net		15.160.204.105
		
		if the ipAddress is 195.116.254.154 the output should be www.gmail.net
	 */
	public String findDomainName(String ipAddress) 
	{
			for (Map.Entry<String,String> entry : domainMap.entrySet()) {
			if (ipAddress.equals(entry.getValue())) {
				return entry.getKey();
			}
		}
		
		//type your logic here
		return "No matching domain name found";
	}
	
}
