package Section08;

import java.util.Scanner;
import java.util.TreeMap;

public class FruitShop {

	public static void main(String[] args) {
	Scanner sc =new Scanner(System.in);
	TreeMap<Integer, String> ma=new TreeMap<Integer, String>();
	System.out.println("Enter the  no of fruits pair you want to store:");
	int c=sc.nextInt();
	for (int i = 1; i <= c; i++) {
		System.out.println("Enter the key"+i);
		int key=sc.nextInt();
		System.out.println("Enter the value"+i);
		String value=sc.next();
		ma.put(key, value);
	}
	sc.close();
	System.out.println("Fruit Details");
	ma.forEach((key,value)->{
		System.out.println(key + " "+value);	
	});

	}
}
