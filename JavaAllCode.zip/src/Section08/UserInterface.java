package Section08;

import java.util.Scanner;

public class UserInterface {

	public static void main(String[] args) {
		PlayerBO b=new PlayerBO();
		Scanner sc =new Scanner(System.in);
		//Fill the UI code
		
		
	boolean f=false;
		while(!f) {
			System.out.println("1. Add overs bowled");
			System.out.println("2. Number of balls bowled");
			System.out.println("3. Exit");
			System.out.println("Enter your choice");
			int choice=sc.nextInt();
		if(choice==1)
		{
			System.out.println("Enter the overs bowled");
			int overs=sc.nextInt();
			b.addOversDetails(overs);
		}
		else if(choice==2)
		{
			System.out.println("Total number of balls bowled");
			System.out.println(b.getNoOfBallsBowled());
			
		}
		else {
			System.out.println("Thank you for using the Application");
			break;
		}}
sc.close();
	}

}