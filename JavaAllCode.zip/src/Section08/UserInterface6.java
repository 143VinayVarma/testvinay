package Section08;

import java.util.Scanner;

public class UserInterface6 {
	public static void main(String[] args)
	{
		Scanner sc =new Scanner(System.in);
		//Type your logic here
		DomainBO b=new DomainBO();
		
		//Fill the UI code
		
		
	boolean f=false;
		while(!f) {
			System.out.println("1. Add DNS details");
			System.out.println("2. Find matching Domain Name");
			System.out.println("3. Exit");
			System.out.println("Enter your choice");
			int choice=sc.nextInt();
		if(choice==1)
		{
			System.out.println("Enter the domain name");
			String domin=sc.next();
			System.out.println("Enter the IP address");
			String ipc=sc.next();
			b.addDNSDetails(domin, ipc);
			
		}
		else if(choice==2)
		{
			System.out.println("Enter the IP address to find the domain name");
			String ip=sc.next();
			System.out.println(b.findDomainName(ip));
			
			
		}
		else {
			System.out.println("Thank you for using the Application");
			break;
		}}
sc.close();
	}	
}
