package Section08;

import java.util.ArrayList;
import java.util.List;

public class LMCBO {
	
private List<String> appointmentDetailsList=new ArrayList<String>();
	
	
	public List<String> getAppointmentDetailsList() {
		return appointmentDetailsList;
	}


	public void setAppointmentDetailsList(List<String> appointmentDetailsList) {
		this.appointmentDetailsList = appointmentDetailsList;
	}


	//This method should add the appointmentDay passed as argument into the appointmentDetailsList
	public void addAppointmentDayDetails (String appointmentDay)
	{
		getAppointmentDetailsList().add(appointmentDay);
	}
	
	
	/* This method should return the maximum number of appointments made based on values available in the appointmentDetailsList 
	
	For Example:
	 if the list contains the following values as [Saturday,Friday,Saturday,Saturday,Monday]
	 the output should be Saturday

	 */
	public int findAppointmentCount(String findDay) 
	{ int sum=-1;
	if(appointmentDetailsList.size()>0) {
		sum++;
		for (int i = 0; i < appointmentDetailsList.size(); i++) {
			if(appointmentDetailsList.get(i).equalsIgnoreCase(findDay)) {
			sum++;
		}	}
	return sum;
			}
		// type your code here
		
		return sum;			
	}
}
