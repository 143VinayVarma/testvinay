package Section08;

import java.util.Scanner;

public class UserInterface3 {
	public static void main(String[] args)
	{
		Scanner sc =new Scanner(System.in);
		//Type your logic here
		RMCBO b=new RMCBO();
		
		//Fill the UI code
		
		
	boolean f=false;
		while(!f) {
			System.out.println("1. Add rainfall details");
			System.out.println("2. Average Rainfall occurred");
			System.out.println("3. Exit");
			System.out.println("Enter your choice");
			int choice=sc.nextInt();
		if(choice==1)
		{
			System.out.println("Enter the Date");
			String date=sc.next();
			System.out.println("Enter the recorded rainfall in mm");
			int grade=sc.nextInt();
			b.addRainfallDetails(grade);
			
		}
		else if(choice==2)
		{
			
			if(b.findAverageRainfallOccured()!=0) {
			System.out.println("Average Rainfall recorded in mm");
			System.out.println(b.findAverageRainfallOccured());
			}else
				System.out.println("No records found");
			
		}
		else {
			System.out.println("Thank you for using the Application");
			break;
		}}
sc.close();
	}	//Type y
	
}
