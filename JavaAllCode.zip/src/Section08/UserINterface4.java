package Section08;

import java.util.Scanner;

public class UserINterface4 {
	public static void main(String[] args)
	{
		Scanner sc =new Scanner(System.in);
		//Type your logic here
		LMCBO b=new LMCBO();
		
		//Fill the UI code
		
		
	boolean f=false;
		while(!f) {
			System.out.println("1. Add appointment details");
			System.out.println("2. Day to find Count");
			System.out.println("3. Exit");
			System.out.println("Enter your choice");
			int choice=sc.nextInt();
		if(choice==1)
		{
			System.out.println("Enter the patient name");
			String name=sc.next();
			System.out.println("Enter the requesting appointment day");
			String day=sc.next();
			b.addAppointmentDayDetails(day);
			
		}
		else if(choice==2)
		{
			System.out.println("Enter the day to find the count");
			String date=sc.next();
			if(date.length()>3) {
	//		if(b.findAppointmentCount(date)!=0) {
			
			System.out.println(b.findAppointmentCount(date));
		//	}else
	//			System.out.println(b.findAppointmentCount(date));
			
		}
			}
		else {
			System.out.println("Thank you for using the Application");
			break;
		}}
sc.close();
	}	//Type y
	
}
