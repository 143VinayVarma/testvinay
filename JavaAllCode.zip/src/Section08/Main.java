package Section08;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		// Type your logic here

		System.out.println("Enter the number of shipment entity :");
		int choice = sc.nextInt();
		sc.nextLine();
		// Fill the UI code
		ArrayList<ShipmentEntity> shp = new ArrayList<ShipmentEntity>(); 

		System.out.println("Enter Shipment entity details : ");

		String[] s = new String[choice];
		for (int i = 0; i < choice; i++) {
			s[i] = sc.nextLine();
			String[] values = s[i].split(",");
			shp.add(new ShipmentEntity(Integer.parseInt(values[0]), values[1], values[2], Long.parseLong(values[3]),
					values[4]));
			}
		sc.close();
		
		
		Collections.sort(shp, new ShipmentEntityComparator());
	
		System.out.format("Shipment entity details :\n%-15s %-15s %-15s %-15s %s\n", "ID", "Name", "Account Number",
				"Credit Limit", "Address");
		for (int i = 0; i < shp.size(); i++) {
			String name = shp.get(i).getName();
			int id = shp.get(i).getId();
			String accountNumber = shp.get(i).getAccountNumber();
			String address = shp.get(i).getAddress();
			long credit = shp.get(i).getCreditLimit();
			System.out.format("%-15s %-15s %-15s %-15s %s\n", id, name, accountNumber, credit, address);
		}
	}
}
