package Section08;

import java.util.ArrayList;
import java.util.List;

public class StudentBO {

	
private List<Integer> studentList=new ArrayList<Integer>();
	
	
	public List<Integer> getStudentList() {
		return studentList;
	}


	public void setStudentList(List<Integer> studentList) {
		this.studentList = studentList;
	}


	//This method should add the marks secured by the students which passed as the argument in to the List
	public void addStudentDetails(int securedMarks)
	{
		getStudentList().add(securedMarks);
		//Type your logic here
	}
	
	
	/* This method should return the pass percentage of the subject 
	passPercentage  can be calculated based on the following formula
	passPercentage= ((Total number of marks greater than 49) * 100) / (Total number of marks in the List) 
	
	For Example:
	 if the list contains the following marks [50,48,75,81,42,95,62]
	 passPercentage= (5*100) * 7  = 71

	 */
	public int findPassPercentage()
	{
				int percentage=-1;
				if(studentList.size()>0)
				{ int k=0;
				
					for (int i = 0; i < studentList.size(); i++) {
					if(studentList.get(i)>49)	
					{
						k++;
					}
					}
					percentage=k*100/studentList.size();
				}
				//Type your logic here
				return percentage;
				
	}

}
