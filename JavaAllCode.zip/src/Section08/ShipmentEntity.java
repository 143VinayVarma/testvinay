package Section08;

public class ShipmentEntity {
int id;
String name,accountNumber,address;
long creditLimit ; 

public ShipmentEntity() {}

public ShipmentEntity(int id,String name,String accountNumber,long creditLimit,String address) {
	this.id=id;
	this.name=name;
	this.accountNumber=accountNumber;
	this.address=address;
	this.creditLimit=creditLimit;
}



public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getAccountNumber() {
	return accountNumber;
}
public void setAccountNumber(String accountNumber) {
	this.accountNumber = accountNumber;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public long getCreditLimit() {
	return creditLimit;
}
public void setCreditLimit(long creditLimit) {
	this.creditLimit = creditLimit;
}

}
