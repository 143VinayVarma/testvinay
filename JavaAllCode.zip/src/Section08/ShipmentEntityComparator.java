package Section08;

import java.util.Comparator;

public class ShipmentEntityComparator implements Comparator<ShipmentEntity> {

	@Override
	public int compare(ShipmentEntity o1, ShipmentEntity o2) {
		// TODO Auto-generated method stub
			return (int) (o1.getCreditLimit() - o2.getCreditLimit()); 
	}

	
}
