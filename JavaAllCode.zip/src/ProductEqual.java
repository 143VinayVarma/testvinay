import java.util.ArrayList;
import java.util.Scanner;

public class ProductEqual {
	static int a, b = 0;
	static int[] arr1, arr2;

	public static void details() {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the array size");
		a = sc.nextInt();
		if (a < 1 || a > 10) {
			System.out.println(a + "is invalid array size");
			sc.close();
			return;
		}
		arr1 = new int[a];
		arr2 = new int[a];
		System.out.println("Enter the elements of the first array");
		for (int i = 0; i < arr1.length; i++) {
			arr1[i] = sc.nextInt();
			if (arr1[i] < 10 || arr1[i] > 999) {
				System.out.println(arr1[i] + " is not a valid input");
				sc.close();
				return;
			}
		}
		System.out.println("Enter the elements of the second array");
		for (int i = 0; i < arr2.length; i++) {
			arr2[i] = sc.nextInt();
			if (arr2[i] < 10 || arr2[i] > 999) {
				System.out.println(arr2[i] + " is not a valid input");
				sc.close();
				return;
			}
		}
	
		ArrayList<Integer> list1=new ArrayList<Integer>();
		ArrayList<Integer> list2=new ArrayList<Integer>();
		for (int i = 0; i < arr2.length; i++) {
			int n=arr2[i];
			int r=0;
			while(n>0)
			{
				r=r+(n%10);
				n=n/10;		
			}
			list2.add(r);
			}
		for (int i = 0; i < arr1.length; i++) {
			int n=arr1[i];
			int r=1;
			while(n>0)
			{
				r=r*(n%10);
				n=n/10;		
			}
			list1.add(r);
				}
int k=0;
for (int i = 0; i < list1.size(); i++) {
	if(list1.get(i)==list2.get(i))
	{
		System.out.println(arr1[i]+","+arr2[i]);
		k++;	
	}
}
if(k==0)
{
	System.out.print("No pair found in "+arr1[0]);
	for (int i = 1; i < arr1.length; i++) {
		System.out.print(" "+arr1[i]);
	}
	System.out.print(" and "+arr2[0]);
	for (int i = 1; i < arr1.length; i++) {
		System.out.print(" "+arr2[i]);
	}
	}
		sc.close();

	}

	public static void main(String[] args) {
		details();
	}
}
