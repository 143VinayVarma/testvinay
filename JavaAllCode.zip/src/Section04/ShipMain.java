package Section04;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class ShipMain {
public static void main(String[] args) throws IOException, ParseException {
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	System.out.println("Enter the shipment details :");
	String shp=br.readLine();
	String[] shiping = shp.split(",");
	System.out.println("Enter the number of shipment status :");
	String status=br.readLine().trim();
	int st=Integer.parseInt(status);
	 DateFormat df2 = new SimpleDateFormat("dd-MM-yyyy");
    Date date2= df2.parse(shiping[3]); 
	
    
    Shipment sp=new Shipment(shiping[0], shiping[1], shiping[2],date2, shiping[4]);
	
	ShipmentStatus[] s=new ShipmentStatus[st];
	int j=0;
	for (int i = 1; i <= st; i++) {
	
	System.out.println("Enter the shipment status "+i+" details :");
	String status1=br.readLine();
	String[] ss = status1.split(",");	
	 DateFormat df3 = new SimpleDateFormat("dd-MM-yyyy");
	 Date date= df3.parse(ss[2]); 
		
	s[j]=new ShipmentStatus(ss[0], ss[1], date, ss[3], sp);
		j++;
	}
	sp.setShipmentStatus(s);
	
	ShipmentBO b=new ShipmentBO();
	b.displayStatusOfShipment(sp);
	
}
	
}
