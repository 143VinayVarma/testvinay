package Section04;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class PfMain {
public static void main(String[] args) throws NumberFormatException, IOException {
	
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	System.out.println("Enter the name:");
	String name=br.readLine();
	
	System.out.println("Enter the salary:");
	float salry=Float.parseFloat(br.readLine());
	
	System.out.println("Enter the pfpercentage:");
	float pf=Float.parseFloat(br.readLine());
	
	PermanentEmployee p=new PermanentEmployee();
	p.setName(name);
	p.setSalary(salry);
	p.setPfpercentage(pf);
	
	boolean b=p.validateInput(salry, pf);
	if(b) {
		
		p.findNetSalary();
		System.out.println("Employee Name:"+p.getName());
		System.out.println("PF Amount:"+String.format("%.2f", p.getPfamount()));
		System.out.println("Netsalary:"+String.format("%.2f", p.getNetsalary()));
		
	}
}
}
