package Section04;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ItemMain {
	public static void main(String[] args) throws IOException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the Item Name:");
		String itemName=br.readLine();
		
		System.out.println("Enter the Item Cost:");
		float itemCost=Float.parseFloat(br.readLine());
		
		System.out.println("Enter the GST:");
		float gst=Float.parseFloat(br.readLine());
		
		TaxableItem i=new TaxableItem();
		i.setGST(gst);
		i.setItemName(itemName);
		i.setItemCost(itemCost);
		int n=i.findTaxAmount();
		if(n==1)
		{
			System.out.println("Total Cost: "+i.getTotalCost());
		}
		else
			System.out.println(n);
		
	}

}
