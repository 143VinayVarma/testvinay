package Section04;

public class PermanentEmployee extends Employee {
	
	private float pfpercentage;
	private float pfamount;
	
	public float getPfpercentage() {
		return pfpercentage;
	}
	public void setPfpercentage(float pfpercentage) {
		this.pfpercentage = pfpercentage;
	}
	public float getPfamount() {
		return pfamount;
	}
	public void setPfamount(float pfamount) {
		this.pfamount = pfamount;
	}
	
	public void findNetSalary() {
		pfamount=getSalary()*pfpercentage/100;
		setNetsalary(getSalary()-pfamount);
	}
	
	public boolean validateInput(float salary,float pfpercent)
	{
		if(salary<1 || pfpercent<0) {
			System.out.println("Error!!! Unable to calculate the NetSalary.");
			return false;}
		else
			return true;
		
	}
}
