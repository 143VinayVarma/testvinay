package Section04;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.DecimalFormat;

public class SMain {
public static void main(String[] args) throws NumberFormatException, IOException {
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	System.out.println("Enter radius:");
	int tid=Integer.parseInt(br.readLine());
	Sphere s=new Sphere(tid);
	DecimalFormat df = new DecimalFormat(".#");
	System.out.printf("Volume of Sphere is "+df.format(s.calculateVolume()));
}
}
