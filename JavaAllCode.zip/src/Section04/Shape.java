package Section04;

public abstract class Shape {
public Shape() {}
abstract public double calculateVolume();
}
