package Section04;

public abstract class Book {
	protected int ISBNNumber;
	protected String bookName;
	protected double price;
	
	public Book() {}

	public Book(int isbn, String bookName, double price)
	{
		this.ISBNNumber=isbn;
		this.bookName=bookName;
		this.price=price;
	}
	
public abstract double calculateDiscount(); 
	
	
	public int getISBNNumber() {
		return ISBNNumber;
	}

	public void setISBNNumber(int iSBNNumber) {
		ISBNNumber = iSBNNumber;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	

}
