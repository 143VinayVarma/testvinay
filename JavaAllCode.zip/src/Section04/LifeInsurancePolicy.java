package Section04;

public class LifeInsurancePolicy extends InsurancePolicy {
private String nomineeName;
private int noOfYears;

public LifeInsurancePolicy() {super();}
public LifeInsurancePolicy(int id,String name, String cName, float amount,String nName, int nYear)
{
super(id, name, cName, amount);
setNomineeName(nName);
setNoOfYears(nYear);
}

public String getNomineeName() {
	return nomineeName;
}
public void setNomineeName(String nomineeName) {
	this.nomineeName = nomineeName;
}
public int getNoOfYears() {
	return noOfYears;
}
public void setNoOfYears(int noOfYears) {
	this.noOfYears = noOfYears;
}
@Override
public float calculateBonus() {
	
	return getAmount()*15/100;
}
}
