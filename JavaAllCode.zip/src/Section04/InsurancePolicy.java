package Section04;

public class InsurancePolicy {
	protected int policyId;
	protected String policyName;
	protected String customerName;
	protected float amount;
	
	public InsurancePolicy(){}

	public InsurancePolicy(int id,String policyName, String customerName,float amount)
	{
		setPolicyId(id);
		setPolicyName(policyName);
		setCustomerName(customerName);
		setAmount(amount);
		
	}
	public int getPolicyId() {
		return policyId;
	}
	public void setPolicyId(int policyId) {
		this.policyId = policyId;
	}
	public String getPolicyName() {
		return policyName;
	}
	public void setPolicyName(String policyName) {
		this.policyName = policyName;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	
	public float calculateBonus() {
			
		return getAmount()*8/100;
	}
	
}
