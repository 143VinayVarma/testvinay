package Section04;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class PolicyMain {
	public static void main(String[] args) throws NumberFormatException, IOException {
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	System.out.println("Enter the Policy Id");
	int policyId=Integer.parseInt(br.readLine());
	
	System.out.println("Enter the Policy Name");
	String policyName=br.readLine();
	
	System.out.println("Enter the Customer Name");
	String customername=br.readLine();
	
	System.out.println("Enter the Amount");
	float amount=Float.parseFloat(br.readLine());
	
	System.out.println("Enter the nominee name");
	String nomineename=br.readLine();
	
	System.out.println("Enter the number of years");
	int nYear=Integer.parseInt(br.readLine());
	
	LifeInsurancePolicy l=new LifeInsurancePolicy(policyId, policyName, customername, amount, nomineename, nYear);
	
	
	System.out.println("Policy Id - "+l.getPolicyId());
	System.out.println("Policy Name - "+l.getPolicyName());
	System.out.println("Customer Name - "+l.getCustomerName());
	System.out.println("Amount - "+l.getAmount());
	System.out.println("Nominee name - "+l.getNomineeName());
	System.out.println("Period - "+l.getNoOfYears());
	System.out.println("Bonus amount - "+l.calculateBonus());
}
}
