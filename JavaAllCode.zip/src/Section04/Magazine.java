package Section04;

public class Magazine extends Book {
	private String magazineType;

	public Magazine() {}
	
	public Magazine(int ISBNNumber,String bookName,double price,String magazineType) {
		super(ISBNNumber, bookName, price);
		this.magazineType=magazineType;
		
	}
	
	public String getMagazineType() {
		return magazineType;
	}

	public void setMagazineType(String magazineType) {
		this.magazineType = magazineType;
	}
	
	public  double calculateDiscount() {
		
		return getPrice()*15/100;
	}

}
