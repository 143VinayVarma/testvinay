package Section04;

public class Sphere extends Shape {
	private int radius;
	
	
	public Sphere(int i)
	{
		setRadius(i);
	}
	public int getRadius() {
		return radius;
	}

	public void setRadius(int radius) {
		this.radius = radius;
	}
	public double calculateVolume() {
		double volume=Math.pow(getRadius(), 3)*4*Math.PI/3;
		return volume;
	}
	

}
