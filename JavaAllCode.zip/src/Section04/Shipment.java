package Section04;

import java.util.Date;

public class Shipment {
private	String id,sourcePort,destinationPort,customerName;
private	Date expectedDeliveryDate;
private	ShipmentStatus[] shipmentStatus;

public Shipment(String id, String sourcePort, String destinationPort,Date expectedDeliveryDate,String customerName) {
	this.id=id;
	this.sourcePort=sourcePort;
	this.destinationPort=destinationPort;
	this.expectedDeliveryDate=expectedDeliveryDate;
	this.customerName=customerName;
}

public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getSourcePort() {
	return sourcePort;
}
public void setSourcePort(String sourcePort) {
	this.sourcePort = sourcePort;
}
public String getDestinationPort() {
	return destinationPort;
}
public void setDestinationPort(String destinationPort) {
	this.destinationPort = destinationPort;
}
public String getCustomerName() {
	return customerName;
}
public void setCustomerName(String customerName) {
	this.customerName = customerName;
}
public Date getExpectedDeliveryDate() {
	return expectedDeliveryDate;
}
public void setExpectedDeliveryDate(Date expectedDeliveryDate) {
	this.expectedDeliveryDate = expectedDeliveryDate;
}
public ShipmentStatus[] getShipmentStatus() {
	return shipmentStatus;
}
public void setShipmentStatus(ShipmentStatus[] shipmentStatus) {
	this.shipmentStatus = shipmentStatus;
}
;

}
