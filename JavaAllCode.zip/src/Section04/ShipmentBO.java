package Section04;

import java.util.Date;

public class ShipmentBO {
	public void displayStatusOfShipment(Shipment shipment) {
		java.util.Date exptda = shipment.getExpectedDeliveryDate();
		ShipmentStatus[] sh = shipment.getShipmentStatus();
		
			Date da2 = sh[sh.length-1].getArrivedDate();
			if(exptda.equals(da2))
		{
			System.out.println("The shipment arrived on time:");
		}
			else if(exptda.before(da2)) {
				System.out.println("The shipment arrived after the expected date:");
			
			}
			else {
				System.out.println("The shipment arrived before the expected date:");

			}
			
	}
}
