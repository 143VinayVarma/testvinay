package Section04;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class PMain {
	static int number;
static	Passenger[] p=null;
	public static void main(String[] args) throws NumberFormatException, IOException {
		Passenger[] pas = getdetails();
		for (int i = 0; i < number; i++) {
			System.out.println(pas[i].toString());
			
		}
	}

	
	public static Passenger[] getdetails() throws NumberFormatException, IOException {
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the no.of passengers:");
		number=Integer.parseInt(br.readLine());
		p=new Passenger[number];
		int j=0;
		for (int i = 1; i <=number ; i++) {
			
			System.out.println("Passenger "+i);
			
			System.out.println("Enter the ticketid:");
			int tid=Integer.parseInt(br.readLine());
			
			System.out.println("Enter the name:");
			String name=br.readLine();
			
			System.out.println("Enter the gender:");
			String gender=br.readLine();
			
			System.out.println("Enter the address:");
			String add=br.readLine();
			
			p[j]=new Passenger(tid, name, gender, add);
			j++;
		}
		return p;
		
		
	}
}
