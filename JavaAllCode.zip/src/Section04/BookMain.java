package Section04;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class BookMain {
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the ISBN Number");
		int isbn=Integer.parseInt(br.readLine());
		
		System.out.println("Enter the Book Name");
		String bookName=br.readLine();
		
		System.out.println("Enter the price");
		double price=Double.parseDouble(br.readLine());
		
		System.out.println("Enter the magazine Type");
		String type=br.readLine();
		
		Magazine m=new Magazine(isbn, bookName, price, type);
		System.out.println("ISBN Number "+m.getISBNNumber());
		System.out.println("Discount Amount "+m.calculateDiscount());
		
	}

}
