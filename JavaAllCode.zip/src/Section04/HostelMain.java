package Section04;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class HostelMain {
public static void main(String[] args) throws NumberFormatException, IOException {
	Hosteller h1 = getHostellerDetails();
	System.out.println(h1.getStudentId()+" "+h1.getName()+" "+h1.getDepartmentId()+" "+h1.getGender()+" "+h1.getPhone()+" "+h1.getHostelName()+" "+h1.getRoomNumber());
}

public static Hosteller getHostellerDetails() throws NumberFormatException, IOException {
	Hosteller h=null;
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	System.out.println("Student Id");
	int id=Integer.parseInt(br.readLine());
	
	System.out.println("Student Name");
	String name=br.readLine();
	
	System.out.println("Department Id");
	int deptid=Integer.parseInt(br.readLine());
	
	
	System.out.println("Gender");
	String gender=br.readLine();
	
	System.out.println("Phone Number");
	String phone=br.readLine();
	
	System.out.println("Hostel Name");
	String hostelName=br.readLine();
	
	System.out.println("Room Number");
	int roomnumber=Integer.parseInt(br.readLine());
//	h=new Hosteller(id, deptid, name, gender, phone, hostelName, roomnumber);
	h=new Hosteller();
	h.setDepartmentId(deptid);
	h.setStudentId(id);
	h.setGender(gender);
	h.setHostelName(hostelName);
	h.setName(name);
	h.setPhone(phone);
	h.setRoomNumber(roomnumber);
	System.out.println("Modify Room Number(Y/N)");
	String mRoom=br.readLine();
	if(mRoom.equalsIgnoreCase("Y"))
	{
	System.out.println("New Room Number");
	int roomnumber1=Integer.parseInt(br.readLine());
	h.setRoomNumber(roomnumber1);
	}
	
	System.out.println("Modify Phone Number(Y/N)");
	String phNumb=br.readLine();
	if(phNumb.equalsIgnoreCase("Y"))
	{
	System.out.println("New Phone Number");
	String phoneNumb=br.readLine();
	h.setPhone(phoneNumb);
	}
	
	return h;
	
}
}
