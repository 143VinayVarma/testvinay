package Section04;

public class Passenger {
	private int ticketid;
	private String name;
	private String gender;
	private String address;
	
	public Passenger(int tid, String name, String gen , String address) {
	this.ticketid=tid;
	this.name=name;
	this.gender=gen;
	this.address=address;
	}
	public int getTicketid() {
		return ticketid;
	}
	public void setTicketid(int ticketid) {
		this.ticketid = ticketid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	public String toString() {
        return "ticketid:"+getTicketid()+",name:"+getName()+",gender:"+getGender()+",address:"+getAddress();
    }
	
}
