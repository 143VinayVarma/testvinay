package Section04;

import java.util.Date;

public class ShipmentStatus {
	private String arrivalPort,departurePort,status;
	private Date arrivedDate;
	private Shipment shipment;
	
	public ShipmentStatus(String arrivalPort,String departurePort,Date date,String status,Shipment shipment ) {
		this.arrivalPort=arrivalPort;
		this.departurePort=departurePort;
		this.arrivedDate=date;
		this.status=status;
		this.shipment=shipment;
	}
	
	
	public String getArrivalPort() {
		return arrivalPort;
	}
	public void setArrivalPort(String arrivalPort) {
		this.arrivalPort = arrivalPort;
	}
	public String getDeparturePort() {
		return departurePort;
	}
	public void setDeparturePort(String departurePort) {
		this.departurePort = departurePort;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getArrivedDate() {
		return arrivedDate;
	}
	public void setArrivedDate(Date arrivedDate) {
		this.arrivedDate = arrivedDate;
	}
	public Shipment getShipment() {
		return shipment;
	}
	public void setShipment(Shipment shipment) {
		this.shipment = shipment;
	}
	
}
