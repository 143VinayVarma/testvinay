import java.text.DecimalFormat;
import java.util.Scanner;

public class CC02 {
	static double bill, amount;
	static double price;

	public static void scanner(double val, Scanner sc) {
		DecimalFormat df=new DecimalFormat("#.##");
		System.out.println(df.format(val) + " is not a valid amount");
		sc.close();
		System.exit(0);
	}

	public static void details() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Amount:");
		bill = sc.nextDouble();
		if (bill <= 0) {
			scanner(bill, sc);
		}

		double num1 = bill;
		double firstTwoDigit = Double.parseDouble(Double.toString(num1).substring(0, 2));
		if (firstTwoDigit <= 50 ) {
			if(bill<1000){
				amount=bill;}
			else
				amount = bill - bill * firstTwoDigit / 100;
		}
		else if(firstTwoDigit >50 ) {
			if(bill<1000){
				amount=bill;}
			else
				amount = bill - bill * 50 / 100;
		}
			
		else
			amount=bill;
}
	public static void main(String[] args) {

		details();
		System.out.println("Amount you have saved on the bill is:");
		System.out.printf("Rs.%.2f", (bill - amount));
		System.out.println("\nAmount to be paid: ");
		System.out.printf("Rs.%.2f", amount);
	}
}
