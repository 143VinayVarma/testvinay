package Section09;

import java.util.ArrayList;
import java.util.List;

public class ShippingCostThread extends Thread  {
private List<Cargo> cargoList;
private List<Double> priceList ;

public ShippingCostThread(List<Cargo> cargoList) throws InterruptedException {
	this.cargoList=cargoList;
	this.start();
}
   
    public void run() {
    	priceList=new ArrayList<Double>();
    	for (int j = 0; j < cargoList.size(); j++) {
			String storage= cargoList.get(j).getStorageType();
			Integer weight = cargoList.get(j).getWeight();
			if (storage.equalsIgnoreCase(Cargo.COLD_STORAGE)) {
				priceList.add(1.85*weight);
			}
			else if(storage.equalsIgnoreCase(Cargo.DRY_STORAGE))
			{
				priceList.add(0.90*weight);
			}
		}
		
	}
        
    

    public List<Cargo> getCargoList() {
        return cargoList;
    }

    public void setCargoList(List<Cargo> cargoList) {
        this.cargoList = cargoList;
    }


    public List<Double> getPriceList() {
        return priceList;
    }

    public void setPriceList(List<Double> priceList) {
        this.priceList = priceList;
    }
    
}
