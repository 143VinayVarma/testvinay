package Section09;

import java.util.List;

public class ZEEShop extends Thread {
	private String memberCategory;
	private int count;
	private List<Member> memberList;

	public ZEEShop(String memberCategory, List<Member> memberList) throws InterruptedException {
		this.memberList = memberList;
		this.memberCategory = memberCategory;
		start();
		join();
		}

	public String getMemberCategory() {
		return memberCategory;
	}

	public void setMemberCategory(String memberCategory) {
		this.memberCategory = memberCategory;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public List<Member> getMemberList() {
		return memberList;
	}

	public void setMemberList(List<Member> memberList) {
		this.memberList = memberList;
	}

	
	@Override
	public void run() {
		int number = 0;
		String category = getMemberCategory();
		for (int j = 0; j < memberList.size(); j++) {
			String cate = memberList.get(j).getCategory();
			if (category.equalsIgnoreCase(cate)) {
				number++;
			}
		}
		setCount(number);
	}
}
