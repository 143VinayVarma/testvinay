package Section09;

import java.util.Scanner;

public class GradeMain {
	
		public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of Threads:");
		int tcount = sc.nextInt();
		sc.nextLine();
		System.out.println("Enter the String:");
		for (int i = 0; i < tcount; i++) {

		String stData = sc.nextLine();
		// System.out.println(stData);
		String stName = stData.split(":")[0];
		// System.out.println(stName);
		int[] marks = new int[5];
		for (int j = 1; j <= marks.length; j++) {
		marks[j - 1] = Integer.parseInt(stData.split(":")[j]);
		}
		new GradeCalculator(stName, marks);
		}
		sc.close();
		
		}

		}
