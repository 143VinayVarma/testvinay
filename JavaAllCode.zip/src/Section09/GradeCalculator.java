package Section09;

public class GradeCalculator extends Thread {
private String studName;
private char result;
private int[] marks;
Thread t;

public void setStudName(String studName) {
this.studName = studName;
}

public String getStudName() {
return studName;
}

public void setResult(char result) {
this.result = result;
}

public char getResult() {
return result;
}

public void setMarks(int[] marks) {
this.marks = marks;
}

public int[] getMarks() {
return marks;
}

public GradeCalculator() {

}

public GradeCalculator(String studName, int[] marks) {
this.studName = studName;
this.marks = marks;
t = new Thread(this, "sample");
t.start();
}

public void run() {
int total = 0;
for (int i = 0; i < 5; i++) {
total = total + marks[i];
// Thread.sleep(1000);
}
if (total >= 400 && total <= 500) {
System.out.println(studName + ":A");
}
if (total >= 300 && total <= 399) {
System.out.println(studName + ":B");
}
if (total >= 200 && total <= 299) {
System.out.println(studName + ":C");
} else if (total < 200) {
System.out.println(studName + ":E");
}
}
}
