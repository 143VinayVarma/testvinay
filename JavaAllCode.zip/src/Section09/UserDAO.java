package Section09;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import section10.DbConnection;

public class UserDAO
{
	public void createUser(User user)
	{
try {
		Connection con = DbConnection.getConnection();
		Statement stmnt = con.createStatement();
		String username=user.getUserName();
		String firstname=user.getFirstName();
		String lastname=user.getLastName();
		String password=user.getPassword();
		Integer id=user.getContact().getId();
		stmnt.executeUpdate("insert into user (username,firstname,lastname,password,contact_id) values ('"+username+"','"+firstname+"','"+lastname+"','"+password+"','"+id+"');");
}
catch (Exception e) {
	// TODO: handle exception
	e.printStackTrace();
}}
	public List<User> findByFirstName(String firstName)
	{
		List<User> list=new ArrayList<User>();
		List<Contact> list1=new ArrayList<Contact>();
		try {
		Connection con = DbConnection.getConnection();
		Statement stmnt = con.createStatement();
		ResultSet rset = stmnt.executeQuery("select * from user join contact on user.contact_id=contact.id where firstname='"+firstName+"';");
		int i=0;
		while(rset.next())
		 {	 list1.add(new Contact(rset.getInt("contact_id"),  rset.getString("mobilenumber"), rset.getString("emailid")));
			 list.add(new User(rset.getInt("Id"), rset.getString("username"),rset.getString("firstname"), rset.getString("lastname"), rset.getString("password"), list1.get(i++)));		 }
		//Fill code
	}catch (Exception e) {
		e.printStackTrace();
	}
		return list;
	}

}
