package Section09;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class TMain {
	public static void main(String[] args) throws NumberFormatException, IOException, InterruptedException {
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the number of orders:");
		int numberOrder = Integer.parseInt(reader.readLine());
		System.out.println("Enter all the orders:");
		String[] o=new String[numberOrder];
		for (int i = 0; i < numberOrder; i++) {
			String orderDetails = reader.readLine();
			o[i]=orderDetails;
		}
		
		if(numberOrder==o.length)
		System.out.println("Enter number of threads to process the data:");
		int threadNumber = Integer.parseInt(reader.readLine());
		TotalOrderThread[] tn = new TotalOrderThread[threadNumber];

		Float d =((float)(numberOrder)/ threadNumber);
		int si=Math.round(d);
		int j = 0;

		for (int i = 0; i < threadNumber; i++) {
			ArrayList<String> s = new ArrayList<String>();
			Map<Integer, Integer> orderMap = new HashMap<Integer, Integer>();
			for (int k = j; k < si; k++) {

				String[] val = o[k].split(",");
				String[] value = val[1].split("/");
				s.add(val[0]);
				orderMap.put(Integer.parseInt(val[0]), Integer.parseInt(value[1]));

			}
			tn[i] = new TotalOrderThread(s, orderMap);
			j = si;
			si = si + si;
			if (si > numberOrder) {
				si =numberOrder;
			}

		}

		Map<String, Integer> map1 = TotalOrderThread.output;
		Iterator<Map.Entry<String, Integer>> itr = map1.entrySet().iterator();
		while (itr.hasNext()) {
			Map.Entry<String, Integer> entry = itr.next();
			if (entry.getValue().equals(0)) {
			//	System.out.println(entry.getKey());
			} else {
				System.out.println(entry.getKey() + " --" + entry.getValue());
			}

		}
	}

}
