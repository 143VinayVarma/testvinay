package Section09;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class TotalOrderThread implements Runnable {
	private List<String> input;
	private Map<Integer, Integer> orderMap;
	public static Map<String, Integer> output = new LinkedHashMap<String, Integer>();
	static int jan = 0, feb = 0, mar = 0, apr = 0, may = 0, jun = 0, jul = 0, aug = 0, sep = 0, oct = 0, nov = 0, dec = 0;

	public TotalOrderThread(List<String> input, Map<Integer, Integer> orderMap) throws InterruptedException {
		this.input = input;
		this.orderMap = orderMap;
		Thread t = new Thread(this);
		t.start();
		t.join();
	}

	public List<String> getInput() {
		return input;
	}

	public void setInput(List<String> input) {
		this.input = input;
	}

	public Map<Integer, Integer> getOrderMap() {
		return orderMap;
	}

	public void setOrderMap(Map<Integer, Integer> orderMap) {
		this.orderMap = orderMap;
	}

	@Override
	public void run() {
		calculated();

	}
	
	public void calculated()
	{
		for (int i = 0; i < getOrderMap().size(); i++) {

			int or = orderMap.get(Integer.parseInt(input.get(i)));
			switch (or) {
			case 1:
				jan++;

				break;
			case 2:
				feb++;

				break;
			case 3:
				mar++;

				break;
			case 4:
				apr++;

				break;
			case 5:
				may++;

				break;
			case 6:
				jun++;

				break;
			case 7:
				jul++;

				break;
			case 8:
				aug++;

				break;
			case 9:
				sep++;

				break;
			case 10:
				oct++;

				break;
			case 11:
				nov++;

				break;
			case 12:
				dec++;

				break;

			}
			output.put("Jan", jan);
			output.put("Feb", feb);
			output.put("Mar", mar);
			output.put("Apr", apr);
			output.put("May", may);
			output.put("Jun", jun);
			output.put("Jul", jul);
			output.put("Aug", aug);
			output.put("Sep", sep);
			output.put("Oct", oct);
			output.put("Nov", nov);
			output.put("Dec", dec);

		}
	}

}
