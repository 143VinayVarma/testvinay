package Section09;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;

public class ExportShipmentThread extends Thread//fill in your code here 
{
	private List<Shipment> shipmentList;
	private StringBuilder shipmentDetails;

	public ExportShipmentThread(List<Shipment> shipmentList) throws InterruptedException {
        this.shipmentList = shipmentList;
        this.start();
        this.join();
    }
	
	public List<Shipment> getShipmentList() {
		return shipmentList;
	}

	public void setShipmentList(List<Shipment> shipmentList) {
		this.shipmentList = shipmentList;
	}

	public void setShipmentDetails(StringBuilder shipmentDetails) {
		this.shipmentDetails = shipmentDetails;
	}

	
    
    public void run() {
          //fill in your code here
    
    	for (int i = 0; i < shipmentList.size(); i++) {
    		 DateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
    		   Long id=shipmentList.get(i).getId();
    		   String name=shipmentList.get(i).getName();
    		   Long bookingNumber=shipmentList.get(i).getBookingNumber();
    		   String executedPlace=shipmentList.get(i).getExecutedPlace();
    		   String executedDate=sdf.format(shipmentList.get(i).getExecutedDate());
    		   String departureDate="";
    		   String arrivalDate="";
    		   Integer totalWeight=shipmentList.get(i).getTotalWeight();
    		   Integer shipmentStatus=shipmentList.get(i).getShipmentStatus();
    		   Integer carrierId=shipmentList.get(i).getCarrierId();
    		 String b=""+id+"|"+name+"|"+bookingNumber+"|"+executedPlace+"|"+executedDate+"|"+departureDate+"|"+arrivalDate+"|"+totalWeight+"|"+shipmentStatus+"|"+carrierId;
    		 StringBuilder bi=new StringBuilder(b);
    		 setShipmentDetails(bi);
    		 System.out.println(getShipmentDetails());
		}
  
        
    }
    
    public StringBuilder getShipmentDetails() {
        return shipmentDetails;
    }
    

}
