package Section09;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ZeeMain {
	public static void main(String args[]) throws InterruptedException {
		Scanner sc = new Scanner(System.in);
		// Type your logic here

		System.out.println("Enter the number of Members:");
		int choice = sc.nextInt();
		sc.nextLine();
		List<Member> list = new ArrayList<Member>();
		List<ZEEShop> list1 = new ArrayList<ZEEShop>();
		
		for (int i = 1; i <= choice; i++) {
			System.out.println("Enter the Member Details:");
			String value = sc.nextLine();
			String[] a = value.split(":");
			list.add(new Member(a[0], a[1], a[2]));
		}
		System.out.println("Enter the number of times Membership category needs to be searched:");
		int count = sc.nextInt();
		sc.nextLine();
	
		for (int i = 0; i < count; i++) {
			System.out.println("Enter the Category");
			String category = sc.nextLine();
			list1.add(new ZEEShop(category,list));
		}
		
		for (int i = 0; i < list1.size(); i++) {
			System.out.println(list1.get(i).getMemberCategory()+":"+list1.get(i).getCount());
		}
			sc.close();

	}
}


