

import java.util.Scanner;

public class Username {
	static String name;

	public static void welcomeUser() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the name:");
		name = sc.nextLine(); // Jennifer
		sc.close();
	}

	public static void main(String[] args) {
		welcomeUser();

		System.out.println("Welcome " + name);

	}

}
