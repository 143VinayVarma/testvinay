package section10;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PrivilageMain {
	public static void main(String[] args)
			throws NumberFormatException, IOException, ClassNotFoundException, SQLException {

		RoleDAO roleDAO = new RoleDAO();
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		PrivilegeDAO privilegeDAO = new PrivilegeDAO();
		List<Privilege> privileges = privilegeDAO.getAllPrivileges();
		System.out.println("List of privileges :");
		System.out.println("Privilege ID Privilege Name");
	//	System.out.format("%-15s %s\n", "Privilege ID", "Privilege Name");
		for (int i = 0; i < privileges.size(); i++) {
	//		System.out.format("%-15s %s\n", privileges.get(i).getId(), privileges.get(i).getName());
			
			System.out.println(privileges.get(i).getId()+" "+ privileges.get(i).getName());
		}
		
		List<Role> lis = new ArrayList<Role>();
		ArrayList<Privilege> pri = new ArrayList<Privilege>();

		System.out.println("Enter number of new Roles to\nbe created :");
		Integer n = Integer.parseInt(br.readLine());

		System.out.println("Enter the role and privileges :");

		for (int i = 0; i < n; i++) {
			String r = br.readLine();
			String[] arr = r.split(",");
			lis.add(new Role(arr[0]));
			for (int j = 1; j < arr.length; j++) {

				pri.add(new Privilege(arr[j]));
			}
			roleDAO.createRole(lis.get(i), pri);

		}
		// fill the code

		System.out.println("Enter the Role :");
		String rol = br.readLine();
		System.out.println("Privileges for " + rol + " :");
		// fill the code
		List<Privilege> prilist = roleDAO.getPreviligeByRole(rol);
		for (int i = 0; i < prilist.size(); i++) {
			System.out.println(prilist.get(i).getName());
		}

	}
}
