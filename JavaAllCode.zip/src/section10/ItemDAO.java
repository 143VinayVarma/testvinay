package section10;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ItemDAO {
	public List<Item> getAllItems() {
		List<Item> list = new ArrayList<Item>();
		try {

			Connection con = DbConnection.getConnection();
			Statement stmnt = con.createStatement();
			ResultSet set = stmnt.executeQuery("select * from item order By Id Asc;");
			//DecimalFormat df = new DecimalFormat("###.#");
			while (set.next()) {
			System.out.println(set.getString("Id") + " " + set.getString("name") + " " + Math.round(set.getDouble("price")* 10)/ 10.0);
			//	System.out.println(set.getString("Id") + " " + set.getString("name") + " " + df.format(set.getDouble("price")));
			}

		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}
		return list;
	}

	public void updateItemPrice(String item, Double price) {
		try {

			Connection con = DbConnection.getConnection();
			Statement stmnt = con.createStatement();
			stmnt.executeUpdate("UPDATE item SET price =" + price + " where Id='" + item + "';");

		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}
	}
}