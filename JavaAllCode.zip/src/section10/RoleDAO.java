package section10;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class RoleDAO {

    public void createRole(Role roleIns, ArrayList<Privilege> privilegeList) throws SQLException, ClassNotFoundException {
    	try {
    		Connection con = DbConnection.getConnection();
    		Statement stmnt = con.createStatement();
    		String name= roleIns.getName();
    		stmnt.executeUpdate("INSERT INTO role (name) VALUES ('" + name + "');");
    		ResultSet set2 = stmnt.executeQuery("select id from role where name='"+name+"';");
    		set2.next();
    		int id=set2.getInt("id");
    		Statement stmnt1 = con.createStatement();
    		Statement stmnt2 = con.createStatement();
    		for (int i = 0; i < privilegeList.size(); i++) {
    		
    		ResultSet set = stmnt1.executeQuery("select id from privilege where name='"+privilegeList.get(i).getName()+"';");
    		
    		while(set.next()) {
    			
    			int pid=set.getInt("id");
    		stmnt2.executeUpdate("INSERT INTO role_privilege (role_id,privilege_id) VALUES ('" + id + "','"+pid+"');");
    		
    		}}
    		
    		} catch (Exception e) {
    	    	// TODO: handle exception
    	    	e.printStackTrace();
    	    }
    	    	
    																																															
    }
    
    
    
    public List<Privilege> getPreviligeByRole(String role) throws ClassNotFoundException, SQLException {
		List<Privilege> li=new ArrayList<Privilege>();
    	try {
    		Connection con = DbConnection.getConnection();
    		Statement stmnt = con.createStatement();
    		ResultSet set = stmnt.executeQuery("select * from role_privilege join role on role.Id=role_privilege.role_id join privilege on privilege.id=role_privilege.privilege_id where role.name='"+role+"' order by privilege_id asc;");
    		while(set.next())
    		{
    		String	name=set.getString("privilege.name");
    		li.add(new Privilege(name));
    		}
    }
    catch (Exception e) {
    	// TODO: handle exception
    	e.printStackTrace();
    }
    	
    	return li;

    	//fill the code

    }

}