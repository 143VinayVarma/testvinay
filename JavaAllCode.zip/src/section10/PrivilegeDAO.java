package section10;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class PrivilegeDAO {
	
	public List<Privilege> getAllPrivileges() throws SQLException, ClassNotFoundException {
		List<Privilege> p=new ArrayList<Privilege>();
		try {
			FileReader fr = new FileReader(new File("script.sql"));
			String s = new String();
			StringBuffer sb = new StringBuffer();
			BufferedReader br = new BufferedReader(fr);

			while ((s = br.readLine()) != null) {
				sb.append(s);
			}
			br.close();
			String[] inst = sb.toString().split(";");

			Connection con = DbConnection.getConnection();
			Statement stmnt1 = con.createStatement();

			for (int i = 0; i < inst.length; i++) {
				if (!inst[i].trim().equals("")) {
					stmnt1.executeUpdate(inst[i]);
				}
			}
			Statement stmnt2=con.createStatement();
			ResultSet set = stmnt2.executeQuery("select * from privilege;");
			while(set.next())
			{
				p.add(new Privilege(set.getInt("id"),set.getString("name")));
			}
			
	}
	catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
	}
		return p;

		//fill the code

	}
	
}