package section10;

import java.util.Scanner;

public class UserMain {
	public static void main (String[] args) {
	    Scanner sc = new Scanner(System.in);
			// Type your logic here
	      	System.out.println("Enter the number of login attempts");
			int choice = sc.nextInt();
		    UserDAO u=new UserDAO();
		    u.makeInActive(choice);
		    u.getInActiveUsers();
		sc.close();
		 
			
	    }
}
