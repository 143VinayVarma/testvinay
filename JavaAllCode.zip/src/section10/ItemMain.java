package section10;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.Statement;

public class ItemMain {

    public static void main(String[] args) throws Exception{
        BufferedReader b = new BufferedReader(new InputStreamReader(System.in));
        //Fill the code here
        System.out.println("Item details :");
		System.out.println("Item ID Item Name Price");
		
		try {
			FileReader fr = new FileReader(new File("script.sql"));
			String s = new String();
			StringBuffer sb = new StringBuffer();
			BufferedReader br = new BufferedReader(fr);

			while ((s = br.readLine()) != null) {
				sb.append(s);
			}
			br.close();
			String[] inst = sb.toString().split(";");

			Connection con = DbConnection.getConnection();
			Statement stmnt = con.createStatement();

			for (int i = 0; i < inst.length; i++) {
				if (!inst[i].trim().equals("")) {
					stmnt.executeUpdate(inst[i]);
				}}}
			catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
				
			}
		ItemDAO d=new ItemDAO();
		d.getAllItems();
        System.out.println("Enter the item id to update :");
        String itemId=b.readLine();
        
        System.out.println("Enter the new price :");
        Double price=Double.parseDouble(b.readLine());
        d.updateItemPrice(itemId, price);
        System.out.println("Item details after update :");
		System.out.println("Item ID Item Name Price");
        d.getAllItems();
    }
    
}
