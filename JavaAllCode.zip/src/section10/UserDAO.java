package section10;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class UserDAO {
	List<User> getInActiveUsers() {
		List<User> list = new ArrayList<User>();
		try {
			Connection con = DbConnection.getConnection();
			Statement stmnt = con.createStatement();
			ResultSet set = stmnt.executeQuery("select * from user where deleted='1' order By Username Asc;");
			System.out.println("Inactive user Details :");
			System.out.println("Name Address Mobile Number");
			while (set.next()) {

				System.out.println(set.getString("Username") + " " + set.getString("Address") + " "
						+ set.getString("Mobilenumber"));
			}

		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}
		return list;
	}

	public void makeInActive(int failedAttempts) {
		try {

			FileReader fr = new FileReader(new File("script.sql"));
			String s = new String();
			StringBuffer sb = new StringBuffer();
			BufferedReader br = new BufferedReader(fr);

			while ((s = br.readLine()) != null) {
				sb.append(s);
			}
			br.close();
			String[] inst = sb.toString().split(";");

			Connection con = DbConnection.getConnection();
			Statement stmnt = con.createStatement();

			for (int i = 0; i < inst.length; i++) {
				if (!inst[i].trim().equals("")) {
					stmnt.executeUpdate(inst[i]);
				}
			}
			stmnt.executeUpdate("UPDATE user SET Deleted =1 where Failedattempts>'" + failedAttempts + "';");
			
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}
	}
}
