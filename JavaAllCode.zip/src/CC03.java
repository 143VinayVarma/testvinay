import java.util.Scanner;

public class CC03 {
	static int a, b;
	static int[] arr1;
	
	public static void details() {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Size of the Array:");
		a = sc.nextInt();
		
		if(a<5 || a>25 )
		{	sc.close();
			if(a<5)
			System.out.println(a +" is small in size");
			else 
			System.out.println(a +" is large in size");
			
			return;
		}
		arr1=new int[a];
		
		System.out.println("Enter the Array elements:");
		for (int i = 0; i < arr1.length; i++) {
			b = sc.nextInt();
			arr1[i]=b;
		}
		sc.close();
		 for (int i = 0; i < arr1.length; i++) {
			 int k =0;
			 for (k= 0; k <i; k++) {
				 if (arr1[i] == arr1[k]) {
					 break;
				 }
			 }
		            
            if (i == k) 
            System.out.println( arr1[i] + " "); 
        }
	} 

	public static void main(String[] args) {
		details();
	}

}
