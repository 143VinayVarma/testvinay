import java.util.Scanner;

public class Triangle {
	
	public static void details()
	{
		int a, b, c;
		Scanner sc = new Scanner(System.in);
		a = sc.nextInt();
		if (a <= 0) {
			System.out.print(a + " is an Invalid Length");
			System.exit(0);
		}
		b = sc.nextInt();
		if (b <= 0) {
			System.out.println(b + " is an Invalid Length");
			System.exit(0);
		}
		c = sc.nextInt();
		if (c <= 0) {
			System.out.println(c + " is an Invalid Length");
			System.exit(0);
		}
		sc.close();

		if (a == b && b == c) {
			System.out.println(a + ", " + b + ", " + c + " are the sides of Equilateral Triangle");
		} else if ((a == b && b != c) || (a != b && a == c) || (a != b && b == c)) {
			System.out.println(a + ", " + b + ", " + c + " are the sides of Isosceles Triangle");
		} else {
			System.out.println(a + ", " + b + ", " + c + " are the sides of Scalene Triangle");
		}
	}
	public static void main(String[] args) {
		details();
	}
}
