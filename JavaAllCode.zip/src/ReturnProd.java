import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class ReturnProd {
	static int a, b=0;
	static int[] arr1,arr2;
	
	public static void details() {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Array size");
		a = sc.nextInt();
		
		if(a<1)
		{sc.close();
			System.out.println(a +" is an invalid array size");
			return;
			}
		arr1=new int[a];
		
		System.out.println("Array elements");
		for (int i = 0; i < arr1.length; i++) {
			arr1[i] = sc.nextInt();
			if(arr1[i]<= 0)
			{
				System.out.println(arr1[i] +" is an invalid array element");
				sc.close();
				return;
			}
		}
		sc.close();
		ArrayList<Integer> list=new ArrayList<Integer>();
		for (int i = 0; i < arr1.length; i++) {
			int count=0;
			
		for (int j = 2; j <=arr1[i]; j++) {
			if(arr1[i]%j==0 && arr1[i]!=2) {
				count++;
				break;
			}
			
			else if(count==0)
			{
				list.add(arr1[i]);
				break;
			}}}
		Iterator<Integer> itr=list.iterator();
		int val=1;
		while(itr.hasNext())
		{
			val=val*itr.next();
		}
		if(val==1)
		{
 System.out.print("No element found in "+arr1[0]);
 for (int i = 1; i < arr1.length; i++) {
	 System.out.print(","+arr1[i]);
	
}}
		else
			System.out.println(val);
	
	}

	public static void main(String[] args) {
		details();
	}
}


