import java.util.Scanner;

public class Numbers {
	static int num, digit, occurance=0;

	public static void scanner(int val, Scanner sc) {
		if (val < 1) {
			System.out.println(val + " falls behind the limit");
		} else {
			System.out.println(val + " exceeds the limit");
		}
		sc.close();
		System.exit(0);
	}

	public static void details() {
		Scanner sc = new Scanner(System.in);
		num = sc.nextInt();
		if (num < 1 || num >= 1000000000) {
			scanner(num, sc);
		}
		digit = sc.nextInt();
		if (digit < 0 || digit > 9) {
			System.out.println(digit + " is not valid");
			System.exit(0);
		}
		sc.close();
		int num1=num;
		while(num1>0) {
		int	m=num1%10;
			if(m==digit)
			{
				occurance++;
			}
			num1=num1/10;
				
		}
	}

	public static void main(String[] args) {
		details();
		if(occurance==0)
		System.out.printf(digit+" is not available in "+num);
		else
			System.out.printf("Count of "+digit+" in "+num+" is "+occurance);
	}

}
