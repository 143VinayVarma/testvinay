import java.util.ArrayList;
import java.util.Scanner;

public class Luckyflat {
	static int a, b;
	static String s;
	static int[] arr1,arr2;
	static ArrayList<Integer> list=new ArrayList<Integer>();
	
	public static void details() {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of flats available:");
		a = sc.nextInt();
		if(a<5 || a>15)
		{
			sc.close();
			System.out.println(a +" is an invalid availability");
			return;
			}
		
		arr1=new int[a];
		System.out.println("Enter the flat numbers:");
		for (int i = 0; i < arr1.length; i++) {
			b=sc.nextInt();
			if(b<100 || b>999)
			{
				sc.close();
				System.out.println(b +" is an invalid flat number");
				return;
			}
			else if(b>799 && b<899) {
				System.out.println(b+" will not be considered");
				sc.close();
				return;
				}
			else {
				arr1[i]=b;
			}
		}
		m1();
		int m=0;
		for (int i = 0; i < arr1.length; i++) {
			if(list.get(i)==5)
			{
				System.out.println(arr1[i]);
				m++;
			}
			
		}
		if(m==0)
		{
			System.out.print("There is no lucky flat in "+arr1[0]);
			for (int i = 1; i < arr1.length; i++) {
				System.out.print(","+arr1[i]);
			}
		}
		
		sc.close();

		
	}
	
	public static void m1() {
		for (int i = 0; i < arr1.length; i++) {
			int n=arr1[i];
			int r=0;
			while(n>0)
			{
				r=r+(n%10);
				n=n/10;		
			}
			if(r>9)
			{
				int k=0;
				while(r>0)
			{
				k=k+(r%10);
				r=r/10;		
			}
				list.add(k);
				}
			else {
				list.add(r);
			}
}}
	public static void main(String[] args) {
		details();
	}
}
