import java.util.Scanner;

public class LC01 {

	static int u_id;
	static String name;
	static String username;
	static String password;
	static String mnumb;
	static double rating;

	public static void details() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the id :");
		u_id = sc.nextInt();
		sc.nextLine();
		System.out.println("Enter the name :");
		name = sc.nextLine();
		System.out.println("Enter the username :");
		username = sc.nextLine();
		System.out.println("Enter the password :");
		password = sc.nextLine();
		System.out.println("Enter the mobilenumber :");
		mnumb = sc.next();
		System.out.println("Enter the rating :");
		rating = sc.nextDouble();
		sc.close();

	}

	public static void main(String[] args) {
		System.out.println("Enter the User Details :");
		details();
System.out.println("User details are :");
		System.out.println("Id : "+u_id);
		System.out.println("Name : "+name);
		System.out.println("Username : "+username);
		System.out.println("Mobile Number : "+mnumb);
		System.out.println("Rating : "+rating);
	}
}
