import java.util.Scanner;
public class AddP {
	

	
	public static void main(String[] args)

	{
	Scanner sc=new Scanner(System.in);
	int cnt, i,j;
	boolean flag=false;
	System.out.print("Enter Starting Range : ");
	int start = sc.nextInt();
	System.out.print("Enter Ending Range : ");

	int end = sc.nextInt();

	System.out.println("List of Prime numbers are:");

	for(i = start ; i <= end ; i++)

	{

	cnt = 0;

	for(j = 1 ; j <= i ; j++)

	{

	if(i % j == 0)

	 cnt = cnt+1;
	}

	if(cnt == 2)
	{

	System.out.println(i);

	flag = true;

	}

	}

	if(flag == false)

	System.out.println("No prime numbers found in the given range");

	sc.close();

	}

	}
