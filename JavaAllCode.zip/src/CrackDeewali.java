import java.util.ArrayList;
import java.util.Scanner;

public class CrackDeewali {
	static int a, b=0;
	static String s,st;
	static String[] arr1,arr2;
	
	public static void details() {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number from the slot");
		a = sc.nextInt();
		
		if(a<5 || a>15)
		{
			sc.close();
			System.out.println(a +" is not a valid slot number");
			return;
			}
		arr1=new String[a];
		System.out.println("Enter the "+a+" customer names");
		for (int i = 0; i < arr1.length; i++) {
			st=sc.next();
			arr1[i] = st.toLowerCase();
		}
		System.out.println("Enter the alphabet from the slot");
		s=sc.next();
		s=s.toLowerCase();
		char c=s.charAt(0);
		sc.close();
		ArrayList<String> list=new ArrayList<String>();
		for (int i = 0; i < arr1.length; i++) {
			int k=0;
			char[] ch = arr1[i].toCharArray();
			for (int j = 0; j < ch.length; j++) {
				if(c==ch[j]) {
					k++;
					break;
				}
				
			}
			if(k!=0)
			{
				list.add(arr1[i]);
			}
			
		}
		if(list.size()>0)
		{
			System.out.println("Customers List");
			for (int i = 0; i < list.size(); i++) {
				System.out.println(list.get(i));
				
			}
		}
		else
		{
			System.out.println("Letter "+s+" is not present in any of the customer's name");
		}
	}
	public static void main(String[] args) {
		details();
	}
}
