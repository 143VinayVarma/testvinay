package Section03.student;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class StudentMain {
	
	public static void main(String[] args) throws NumberFormatException, IOException {
	
		Student s=getStudentDetails();
		System.out.println("Id:"+s.getId());
		System.out.println("Name:"+s.getName());
		System.out.println("Average:"+s.getAverage());
		System.out.println("Grade:"+s.getGrade());
	}
	public static Student getStudentDetails() throws NumberFormatException, IOException {
		Student s=null;
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the id:");
		int id=Integer.parseInt(br.readLine());

		System.out.println("Enter the name:");
		String name=br.readLine();
		
		int sid=0;
		int flag=0;
		do{
			System.out.println("Enter the no of subjects:");
			sid=Integer.parseInt(br.readLine());
			flag=0;
			if(sid<1) {
			System.out.println("Invalid number of subject");
			flag=1;
			}
		}while(flag==1);
		
		int[] m=new int[sid];
		for (int i = 0; i < m.length; i++) {
			int f=0;
			do {
				System.out.println("Enter mark for subject "+(i+1)+":");
				int c=Integer.parseInt(br.readLine());
				if(c<0 || c>100)
				{
					System.out.println("Invalid Mark");
					f=1;	
				}
				else {
					m[i]=c;
				}
			}while(f==1);
		}
		
		s=new Student(id, name, m);

		return s;
		
	}
}
