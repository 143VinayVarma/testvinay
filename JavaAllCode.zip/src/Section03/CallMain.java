package Section03;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class CallMain {
public static void main(String[] args) throws IOException {
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	System.out.println("Enter the call details:");
	String details=br.readLine();
	Call c=new Call();
	c.parseData(details);
	System.out.println("Call id:"+c.getCallId());
	System.out.println("Called number:"+c.getCalledNumber());
	System.out.println("Duration:"+c.getDuration());

}
}
