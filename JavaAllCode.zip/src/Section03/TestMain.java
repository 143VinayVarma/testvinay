package Section03;

import java.util.Scanner;

public class TestMain {
public static void main(String[] args) {
	BusTicket b=getTicketDetails();
	System.out.println("Ticket no:"+b.getTicketNo());
	System.out.println("Passenger Name:"+b.getPerson().getName());
	System.out.println("Price of a ticket :"+b.getTicketPrice());
	System.out.println("Total Amount :"+b.getTotalAmount());
}

public static BusTicket getTicketDetails()
{	BusTicket b=null;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the passenger name:");
	String name=sc.nextLine();

	System.out.println("Enter the gender(M/m or F/f):");
	String gender=sc.nextLine();
	
	System.out.println("Enter the age:");
	int age=Integer.parseInt(sc.nextLine());
	
	System.out.println("Enter the ticket no:");
	int tno=Integer.parseInt(sc.nextLine());
	
	System.out.println("Enter the ticket price:");
	float tprice=Float.parseFloat(sc.nextLine());
	
	sc.close();
	Person p=new Person();
	p.setAge(age);
	p.setGender(gender.charAt(0));
	p.setName(name);
	b=new BusTicket();
	b.setTicketNo(tno);
	b.setTicketPrice(tprice);
	b.setPerson(p);
	b.calculateTotal();
	return b;
	}
}
