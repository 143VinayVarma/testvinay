package Section03;

public class Account {
	 public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	private int accountId,balance;
	 private String accountType ;
	
	
//	public  Account(int accountId, int balance,String accountType)
//	{
//		this.accountId=accountId;
//		this.balance=balance;
//		this.accountType=accountType;
//	}
	public boolean withdraw(int val) {
		if(getBalance()>val)
		{
			System.out.println("Balance amount after withdraw: "+(balance-val));
			return true;
		}
		else {
			System.out.println("Sorry!!! No enough balance");
			return false;
		}
		
	}
}
