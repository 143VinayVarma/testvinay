package Section03;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class AccountDetails {
	
	public static void main(String[] args) throws NumberFormatException, IOException {
		AccountDetails s1=new AccountDetails();
		Account s=s1.getAccountDetails();
		s.withdraw(s1.getWithdrawAmount());
				}
	
	public  Account getAccountDetails() throws NumberFormatException, IOException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter account id:");
		int id=Integer.parseInt(br.readLine());

		System.out.println("Enter account type:");
		String account=br.readLine();

		int flag =0;
		int bal=0;
		do
		{
			System.out.println("Enter balance:");
			bal=Integer.parseInt(br.readLine());
			flag =0;
			if(bal<1)
			{
				System.out.println("Balance should be positive");
				flag =1;
			}
		}while(flag==1);
		Account s=null;
		s=new Account();
		s.setAccountId(id);
		s.setAccountType(account);
		s.setBalance(bal);
		return s;
	}
	
	public int getWithdrawAmount() throws NumberFormatException, IOException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		 int flag =0,withdraw=0;
		do
			{
			System.out.println("Enter amount to be withdrawn:");
			 withdraw=Integer.parseInt(br.readLine());
				flag =0;
				if(withdraw<1)
				{
					System.out.println("Amount should be positive");
					flag =1;
				}
			}while(flag==1);
		return withdraw;
	}
}
