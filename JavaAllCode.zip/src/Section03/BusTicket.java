package Section03;

public class BusTicket {
private int ticketNo;
private float ticketPrice;
private float totalAmount;
private Person person;

public int getTicketNo() {
	return ticketNo;
}
public void setTicketNo(int ticketNo) {
	this.ticketNo = ticketNo;
}
public float getTicketPrice() {
	return ticketPrice;
}
public void setTicketPrice(float ticketPrice) {
	this.ticketPrice = ticketPrice;
}
public float getTotalAmount() {
	return totalAmount;
}
public void setTotalAmount(float totalAmount) {
	this.totalAmount = totalAmount;
}
public Person getPerson() {
	return person;
}
public void setPerson(Person person) {
	this.person = person;
}

public void calculateTotal() {
	int age=getPerson().getAge();
	float price=getTicketPrice();
	char c=getPerson().getGender();
	if(age<16)
	{
	price=getTicketPrice()-getTicketPrice()*50/100;
		setTotalAmount(price);
	}
	else if(age>60)
	{
		price=getTicketPrice()-getTicketPrice()*25/100;
		setTotalAmount(price);
	}
	else if(c=='F' || c=='f') {
		price=getTicketPrice()-getTicketPrice()*10/100;
		setTotalAmount(price);
	}
	else {
		setTotalAmount(price);
	}
}

}
