import java.util.ArrayList;
import java.util.Scanner;

public class UniquePrd {
	static int a, b;
	static int[] arr1;
	
	public static void details() {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of items:");
		a = sc.nextInt();
		
		if(a<5 || a>20 )
		{sc.close();
			System.out.println(a +" is an invalid item count");
			return;
			}
		arr1=new int[a];
		
		System.out.println("Enter the bar code ID for 10 items:");
		for (int i = 0; i < arr1.length; i++) {
			b = sc.nextInt();
			if(b<100 || b>999)
			{
				System.out.println(b +" is an invalid bar code ID");
				sc.close();
				return;
			}
			else
				arr1[i]=b;
		}
		sc.close();
		
		ArrayList<Integer> list=new ArrayList<Integer>();
		for (int i = 0; i < arr1.length; i++) {
			int a=arr1[i],x=0,y=0,z=0;
			while(a>0)
			{


				x=a%10;
				a=a/10;
				y=a%10;
				a=a/10;
				z=a%10;
				
				if(x!=y && y!=z && z!=x)
				{
					list.add(arr1[i]);
				}
				break;
		

		}}
		
		if(list.size()>0)
		{
			for (int j = 0; j < list.size(); j++) {
				System.out.println(list.get(j));
			}
			System.out.print("There are "+list.size()+" items with Unique number in the bar code ID");
		}
		else
		{
			System.out.print("There are no items with Unique number in "+arr1[0]);
			for (int i = 1; i < arr1.length; i++) {
				System.out.print(","+arr1[i]);
			}
		}
	}

	public static void main(String[] args) {
		details();
	}
}
