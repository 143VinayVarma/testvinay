package section07;

import java.util.ArrayList;
import java.util.Scanner;

public class Word {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the string:");
		String input = sc.nextLine().toLowerCase();

		char[] data = input.toCharArray();
		stringCheck(data);
	
		System.out.println("Enter the string to be searched:");
		String search = sc.nextLine().toLowerCase();

		char[] sh = search.toCharArray();
		stringCheck(sh);
		
		int k=search.length();
		
		sc.close();
		
		int count=0,m=0;
		for (int j = 0; j < data.length-k; j++) {
			if(search.equalsIgnoreCase(input.substring(j, j+search.length()))){
				m=2*j+k-1;
				count++;
			}}
		
		if(count==0) {
			System.out.println(search+" not found");
			return;
		}
		else if(count>1)
		{
			System.out.println(search+" is found more than once");
			return;
		}
		else {
			System.out.println(m);
		}
		
	
	}


	public static void stringCheck(char[] data)
	{ 	ArrayList<Character> list=new ArrayList<Character>();
		for (int i = 0; i < data.length; i++) {
			if(data[i]>=65 && data[i]<=90   || data[i]>=97 && data[i]<=122 || data[i]==' ')
			{
			continue;
			}
			else {
				list.add(data[i]);
			}
		}
		 if(list.size()>0)
		 {
			 System.out.print("String should not contain ");
			 for (int i = 0; i < list.size(); i++) {
				System.out.print(list.get(i));
			}
			 System.exit(0);
		 }
	}
}
