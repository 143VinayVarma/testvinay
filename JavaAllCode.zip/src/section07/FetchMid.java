package section07;

import java.util.ArrayList;
import java.util.Scanner;

public class FetchMid {
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the string:");
		String input=sc.next();
		int k=input.length();
		sc.close();
		if(k<3)
		{
			System.out.println("The string "+input+" is too short");
				return;
		}
		char[] data=input.toCharArray();
		
	 	ArrayList<Character> list=new ArrayList<Character>();
			for (int i = 0; i < data.length; i++) {
				if(data[i]>=65 && data[i]<=90   || data[i]>=97 && data[i]<=122)
				{
				continue;
				}
				else {
					list.add(data[i]);
				}
			}
			 if(list.size()>0)
			 {
				 System.out.print("The string should not have ");
				 for (int i = 0; i < list.size(); i++) {
					System.out.print(list.get(i));
				}
				return;			 }
		System.out.println("Middle characters:");
		if(k%2==0)
		{
			System.out.println(input.substring(k/2-1, k/2+1));
		}
		else
		{
			System.out.println(input.substring(k/2,k/2+1));
		}
		
	}}
