package section07;

import java.util.ArrayList;
import java.util.Scanner;

public class Changecase {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String input=sc.nextLine();
		if(input.length()<3)
		{
			System.out.println("String length of "+input.length()+" is too short");
			sc.close();
			return;
		}
		else if(input.length()>10)
		{
			System.out.println("String length of "+input.length()+" is too long");
			sc.close();
			return;
		}
		
	
		 char[] data=input.toCharArray();
		 ArrayList<Character> list=new ArrayList<Character>();
		 
		 for (int i = 0; i < data.length; i++) {
			if(data[i]>=65 && data[i]<=90   || data[i]>=97 && data[i]<=122 )
			{
			continue;
			}
			else {
				list.add(data[i]);
			}
		}
		 if(list.size()>0)
		 {
			 System.out.print("String should not contain ");
			 for (int i = 0; i < list.size(); i++) {
				System.out.print(list.get(i));
			}
			 sc.close();
			 return;
		 }
		 char ch=sc.next().charAt(0);
		 int count=0;
		 for (int i = 0; i < data.length; i++) {
			 
			if(ch==(data[i]+32) )
			{
				data[i]=(char) (data[i]+32);
				count++;
			}
			else if(ch==(data[i]-32) || ch==data[i])
			{
				data[i]=(char) (data[i]-32);
				count++;
			}
			
		}
		 sc.close();
		if(count==0)
		System.out.println("Character not found");
		else
		 System.out.println(new String(data));
	}
}
