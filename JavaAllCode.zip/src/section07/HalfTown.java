package section07;

import java.util.ArrayList;
import java.util.Scanner;

public class HalfTown {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the string:");
	String input=sc.nextLine();
	sc.close();
	if(input.length()<2)
	{
		System.out.println("Size of string "+input+" is too low");
		return;
	}
	char[] data=input.toCharArray();
	ArrayList<Character> list=new ArrayList<Character>();
	int k=input.length();
	for (int i = 0; i < data.length; i++) {
		if(data[i]>=65 && data[i]<=90   || data[i]>=97 && data[i]<=122 || data[i]==' ')
		{
		continue;
		}
		else {
			list.add(data[i]);
		}
	}
	 if(list.size()>0)
	 {
		 System.out.print(String.valueOf(data)+" is not a valid string");
		return;
	 }	


	String s=input.substring(0,k/2);
	String s1=input.substring(k/2, k);
	StringBuffer b=new StringBuffer(s1);
	b.reverse();
	String output=s+b;
	System.out.println(output);
	}


}