package section07;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

public class Recharge {
	public static void main(String args[]) throws ParseException {
		Scanner s = new Scanner(System.in);
		System.out.println("Recharged date");
		String dateInput = s.next();
		Date enterDate = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		enterDate = sdf.parse(dateInput);
		String currentDateGiven = "29/10/2019";
		Date currentDate = sdf.parse(currentDateGiven);
		if (!(dateInput.equals(sdf.format(enterDate)) && !(enterDate.compareTo(currentDate) > 0))) {
		System.out.println(dateInput + " is not a valid date");
		return;
		}
		System.out.println("Validity days");
		int validity = s.nextInt();
		if (validity <= 0) {
		System.out.println(validity + " is not a valid days");
		return;
		}

		Calendar c = Calendar.getInstance();
		try {
		c.setTime(sdf.parse(dateInput));
		} catch (ParseException e) {
		e.printStackTrace();
		}
		c.add(Calendar.DAY_OF_MONTH, validity);
		String newDate = sdf.format(c.getTime());
		System.out.println(newDate);
		}

}
