package section07;

import java.util.Scanner;

public class Substitution {
	  public static void main(String args[]) {
	        Scanner sc = new Scanner(System.in);
	        System.out.println("Enter the encrypted text:");
	        String ciphertext = sc.nextLine();
	        int shift = 7;
	        String decryptMessage = "";
	        int count=0;
	        for(int i=0; i < ciphertext.length();i++)  
	        {
	            // Shift one character at a time
	            char alphabet = ciphertext.charAt(i);
	            // if alphabet lies between a and z 
	            if(alphabet >= 'a' && alphabet <= 'z')
	            {
	                // shift alphabet
	                alphabet = (char) (alphabet - shift);
	            
	                // shift alphabet lesser than 'a'
	                if(alphabet < 'a') {
	                    //reshift to starting position 
	                    alphabet = (char) (alphabet-'a'+'z'+1);
	                }
	                decryptMessage = decryptMessage + alphabet;
	                count++;
	            }    
	                // if alphabet lies between A and Z
	            else if(alphabet >= 'A' && alphabet <= 'Z')
	            {
	             // shift alphabet
	                alphabet = (char) (alphabet - shift);
	                
	                //shift alphabet lesser than 'A'
	                if (alphabet < 'A') {
	                    // reshift to starting position 
	                    alphabet = (char) (alphabet-'A'+'Z'+1);
	                }
	                decryptMessage = decryptMessage + alphabet;  
	                count++;
	            }
	           
	            else if(alphabet ==' ') 
	            {
	            	
	            decryptMessage = decryptMessage + alphabet;   
	            
	            }
	            else
	            	continue;
	        }
	        sc.close();
	        if(count>0)
	        System.out.println("Decrypted text:\n" + decryptMessage);
	        else {
	        	System.out.println("No hidden message for "+ciphertext);
	        }
	    }
	}
