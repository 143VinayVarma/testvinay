package section07;

import java.text.ParseException;
import java.util.Scanner;

public class Hexa {
	public static void main(String[] args) throws ParseException {
		Scanner sc=new Scanner(System.in);
		String hex=sc.nextLine();
		hex = hex.toUpperCase();
	sc.close();
	try{
		int num = Integer.parseInt(hex,16);
		if(hex.length()<4 || hex.length()>5)
		{
			System.out.println(hex+" is a "+hex.length()+" digit input");
			return;
		}
		System.out.println(num);
		
		}
	catch (Exception e) {
		System.out.println(hex+" is Invalid");
	}
	
}}
