import java.util.Scanner;

public class Cars {
	static int b1,b2,b3,b4,carCount;
	
	public static void scanner(int val, Scanner sc)
	{
		System.out.println(val + " is not a valid input");
		sc.close();
		System.exit(0);
	}

	public static void carparking(String s) {
		System.out.println("The car can be parked at "+s);
	}
	
	public static void details() {
		Scanner sc = new Scanner(System.in);
		System.out.println("B1");
		b1 = sc.nextInt();
	 if(b1 < 0)
		 scanner(b1, sc);
	 System.out.println("B2");
		b2 = sc.nextInt();
	 if(b2 < 0)
		 scanner(b2, sc);
	 System.out.println("B3");
		b3 = sc.nextInt();
	 if(b3 < 0)
		 scanner(b3, sc);
	 System.out.println("B4");
		b4 = sc.nextInt();
	 if(b4 < 0)
		 scanner(b4, sc);
	 System.out.println("Car Count");
		carCount = sc.nextInt();
	 if(carCount < 0)
		 scanner(carCount, sc);
	 sc.close();
	 int n=b1+b2+b3+b4;
	 
	 if(carCount>n)
	 System.out.println("Parking slots in full");
	
	 if(carCount<=b1)
	 carparking("B1");
	 
	 else if(carCount<=b1+b2)
		 carparking("B2");
	 
	 else if(carCount<=b1+b2+b3)
		 carparking("B3");
	 
	 else if(carCount<=n)
		 carparking("B4");
	
}
	
	public static void main(String[] args) {
		 details();
	}
}
