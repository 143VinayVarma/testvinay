import java.util.ArrayList;

public class demo {
	public static void main(String[] args) {
		 int[] arr1= {10,12,82};
		 int[] arr2= {11,12,97};
		ArrayList<Integer> list1=new ArrayList<Integer>();
		ArrayList<Integer> list2=new ArrayList<Integer>();
		for (int i = 0; i < arr1.length; i++) {
			int n=arr1[i];
			int r=0;
			while(n>0)
			{
				r=r+(n%10);
				n=n/10;		
			}
			list1.add(r);
			}
		for (int i = 0; i < arr2.length; i++) {
			int n=arr2[i];
			int r=1;
			while(n>0)
			{
				r=r*(n%10);
				n=n/10;		
			}
			list2.add(r);
				}


}
}