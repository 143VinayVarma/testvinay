import java.util.Arrays;
import java.util.Scanner;
import java.util.TreeMap;

public class ReducedForm {
	static int a, b;
	static int[] arr;
	
	public static void details() {
		
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the size of Array:");
		a = sc.nextInt();
		
		if(a<5 || a>10 )
		{
			sc.close();
			System.out.println(a +" is an invalid array size");
			return;
		}
		arr=new int[a];
		for (int i = 0; i < arr.length; i++) {
			
			arr[i]=sc.nextInt();
		}
		sc.close();
		int b[] = arr.clone();
		//LinkedHashMap<Integer, Integer> map=new LinkedHashMap<>();
		Arrays.sort(b);
		int c=0;
		TreeMap<Integer, Integer> map=new TreeMap<>();
		for (int i = 0; i < b.length; i++) {
			map.put(b[i], c++);
			
		}
//		if(map.size()>0)
//		{
//			System.out.print(map.get(arr[0]));
//		}
		for (Integer value: map.values()) {
			System.out.print(value+" ");
		}
		for (int j = 0; j < map.size(); j++) {
		
				System.out.print(map.get(arr[j])+" ");
				}}

	public static void main(String[] args) {
		details();
	}
}
