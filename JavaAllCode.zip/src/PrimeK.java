import java.util.Scanner;

public class PrimeK {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the first number");
		int n1 = sc.nextInt();
		boolean flag = false;
		System.out.println("Enter the last number");
		int n2 = sc.nextInt();
		sc.close();
		
		if(n1<n2)
		{
			n1=n1+1;
		}
		int a = n1;
		int b = n2;
		int num1 = a;
		if (n1 > n2) {
			int c = n1;
			n1 = n2;
			n2 = c;
		int	num = n2;
			int k = 0;
			// to write the last nearest prime number : remove if condition if last prime
			// if(b>a) {
			for (int i = 2; i < num / 2; i++) {
				if (num % i == 0) {
					flag = true;
					break;
				}

			}
			if (flag) {
				flag = false;
				m1(++num);
				while (num % 10 != 1) {
					m1(++num);
				}

			// reverse way checking
			//reverseorder();
		}

		else {
			num = n2;
			normalorder();
		}
	}

}
