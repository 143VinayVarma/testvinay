import java.util.Scanner;

public class Megamart {
	static int c_id;
	static double billamount;
	static double bill;
	static int x=0;
	public static int details() {
	if (billamount < 0.00) {
			System.out.println(Math.round(billamount) + " is not a valid Bill Amount");
			return 0;
		} else if (billamount >= 1000.00) {
			if (c_id >= 1 && c_id <= 100)
				bill = billamount - billamount * .15;
			if (c_id >= 101 && c_id <= 250)
				bill = billamount - billamount * .18;
			if (c_id >= 251 && c_id <= 500)
				bill = billamount - billamount * .23;
			if (c_id >= 501 && c_id <= 1000)
				bill = billamount - billamount * .28;
			if (c_id >= 1001)
				bill = billamount - billamount * .32;
		} else if (billamount < 1000.00 && billamount > 0)
			bill = billamount;
			return 1;
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Customer Id");
		c_id = sc.nextInt();
		sc.nextLine();
		if (c_id <= 0) {
			System.out.println(c_id + " is not a valid Customer Id");
			sc.close();
			}
		else {
			System.out.println("Enter the Bill amount");
			billamount = sc.nextDouble();
			sc.close();
			x = details();
		}
		if (x == 1) {
			System.out.printf("Total Price is %.2f",bill);
			
	}}}
