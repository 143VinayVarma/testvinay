package section05;


public class Validator {
	
	public static boolean validateConfiguration(int ramCapacity,int hdCapacity,int olNetConnection)throws ConfigurationMisMatchException{
		boolean flag = false;
		
		if (ramCapacity>=6 && hdCapacity>=30 && olNetConnection>=192){
			flag=true;
		}
		else{
		throw new ConfigurationMisMatchException("Sorry cannot install the game");
		}
		
		
		return flag;
		
	}

}