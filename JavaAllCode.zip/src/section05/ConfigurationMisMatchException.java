	package section05;
	
	public class ConfigurationMisMatchException extends Exception{
	
		
		public ConfigurationMisMatchException(String messge) {
			super(messge);
		}
		
		private static final long serialVersionUID = 1L;
	
	//	@Override
	//	public String getMessage() {
	//		// TODO Auto-generated method stub
	//		return "Sorry cannot install the game";
	//	}
	//	
	}
