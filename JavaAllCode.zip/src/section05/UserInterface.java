package section05;
import java.util.Scanner;


public class UserInterface {

	public static void main(String[] args) throws ConfigurationMisMatchException{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the RAM capacity (in GB)");
		int rCapacity=sc.nextInt();
		System.out.println("Enter the HD capacity available (in GB)");
		int hdCapacity = sc.nextInt();
		System.out.println("Enter the Net Connection speed (in KBPS)");
		int speed = sc.nextInt();
		sc.close();
		boolean flag=false;
		try {
		flag=Validator.validateConfiguration(rCapacity, hdCapacity, speed);
		if(flag) {
			System.out.println("Thank you for installing the game");
			
		}
		}
		catch (ConfigurationMisMatchException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		
		
 		//fill in the code
 		

	}

}
