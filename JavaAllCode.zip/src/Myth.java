
public class Myth extends Thread {
	public Myth()
	{
		this.start();
	}
	public void check() {
		System.out.println("DInesh");
	}
	
		public void run() {
			System.out.println("Run");
			check();
		}
	public static void main(String[] args) {
		Myth m=new Myth();
		m.run();
	}

}
