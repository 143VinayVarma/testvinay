import java.util.Scanner;

public class p {
	static int num;
	public static void checklastdigit(int last)
	{
		boolean flag=false;
		for (int i = 2; i < last/2; i++) {
			if(last%i==0)
			{
				flag=true;
				break;
			}
			
		}
		if(flag) {
			flag=false;
			m1(++num);
			while(num%10!=1) {
				m1(++num);
		}
			
	}}
	
	public static void m1(int j)
	{ boolean flag=false;
		for (int i = 2; i < j/2; i++) {
			if(j%i==0)
			{
				flag=true;
				break;
			}
			}
		if(flag) {
			flag=false;
			m1(++num);
		}
	}
public static void main(String[] args) {
	int a, b;
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter the first number");
	a = sc.nextInt();
	System.out.println("Enter the last number");
	b = sc.nextInt();
	sc.close();
	if(a>b)
	{
		int c=a;
		a=b;
		b=c;
	}
	num=b;
	checklastdigit(b);
	for (int j = a; j <=num; j++) {
		boolean flag=false;
		for (int i = 2; i < j/2; i++) {
			if (j%i==0) {
				flag=true;
				break;
			}
		}
		if(!flag)
		{
			while (j%10==1) {
				System.out.print(j);
				if(j!=num)
				{
					System.out.print(",");
				}
				break;
			}
			
		}
	}
	
	
}
}
//4201,4211,4231,4241,4261,4271,4391,4421