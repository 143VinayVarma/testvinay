import java.util.Scanner;

public class BillUserName {
	static int piza;
	static int puff;
	static int cooldrinks;
	static int pprice=100;
	static int puffprice=20;
	static int cprice=10;
	public static void carDetails()
	{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the no of pizzas bought");
	piza=sc.nextInt();
	System.out.println("Enter the no of puffs bought");
	puff=sc.nextInt();
	System.out.println("Enter the no of cool drinks bought");
	cooldrinks=sc.nextInt();
	sc.close();

	}
	public static void main(String[] args) {
		carDetails();
		System.out.println("Bill Details");
		System.out.println("No of pizzas \n"+piza);
		System.out.println("No of puffs \n"+puff);
		System.out.println("No of cool drinks \n"+cooldrinks);
		System.out.println("Total price \n"+(piza*pprice+puffprice*puff+cprice*cooldrinks));
		System.out.println("ENJOY THE SHOW!!!");
	}
}
