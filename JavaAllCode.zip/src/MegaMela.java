
public class MegaMela {

}
