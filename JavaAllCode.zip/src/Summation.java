import java.util.Scanner;

public class Summation {
	public static void main(String[] args) {
		 int a=0, b=0;
		int[] arr1=null,arr2=null;
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the array size");
		a = sc.nextInt();
		if(a<1 || a>10)
		{
			System.out.println(a +" is an invalid array size");
			sc.close();
			return;
		}
		arr1=new int[a];
		System.out.println("Enter the elements in first array");
		for (int i = 0; i < arr1.length; i++) {
			arr1[i] = sc.nextInt();
			if(arr1[i]%2==0 || arr1[i]==0)
			{
				b++;
			}}
		arr2=new int[a];
		System.out.println("Enter the elements in second array");
		for (int i = 0; i < arr2.length; i++) {
			arr2[i] = sc.nextInt();
				if(arr2[i]%2==0 || arr2[i]==0)
			{
				b++;
				}
		}
		if(b==0)
		{
			System.out.print("There are no even elements in the arrays");
			sc.close();
			return;
		}
		else{
			for (int i = 0; i < arr1.length; i++) {
			if(arr1[i]%2==0 && arr2[i]%2==0)
	{
		System.out.println(arr1[i]+arr2[i]);
	}
	else
		System.out.println(0);	
		}
		}	
		sc.close();
	}
}
