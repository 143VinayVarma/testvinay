import java.util.Scanner;

public class Holiday {
	static int pass_num, price;
	static double discount = 0, n_discount = 0, fare;
	static String f_name, f_class, payment;

	public static void scanner(int val, Scanner sc) {
		if (val < 1) {
			System.out.println(val + " falls behind the limit");
		} else {
			System.out.println(val + " exceeds the limit");
		}
		sc.close();
		System.exit(0);
	}

	public static void details() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the flight name");
		f_name = sc.nextLine();
		System.out.println("Enter the class");
		f_class = sc.nextLine();
		System.out.println("Enter the number of seats");
		pass_num = sc.nextInt();
		sc.nextLine();
		System.out.println("Card Payment");
		payment = sc.nextLine();
		sc.close();
		switch (f_name) {
		case "Air India":
			if (payment.equals("Y"))
				discount = 10.5;
			if (f_class.equals("Economy class"))
				price = 6950;
			else if (f_class.equals("Travel class"))
				price = 3200;
			else if (f_class.equals("Business class"))
				price = 10340;
			break;
		case "Spice Jet":
			if (pass_num > 5 && pass_num < 11)
				n_discount = 10;
			else if (pass_num > 10)
				n_discount = 15;
			if (payment.equals("Y"))
				discount = 7.5;
			if (f_class.equals("Economy class"))
				price = 7945;
			else if (f_class.equals("Travel class"))
				price = 3450;
			else
				price = 9500;
			break;
		case "Go Air":
			if (payment.equals("Y"))
				discount = 9.5;
			if (f_class.equals("Economy class"))
				price = 7250;
			else if (f_class.equals("Travel class"))
				price = 3300;
			else
				price = 9890;
			break;
		case "IndiGo":
			if (pass_num > 5 && pass_num < 11)
				n_discount = 10;
			else if (pass_num > 10)
				n_discount = 15;
			if (payment.equals("Y"))
				discount = 8.5;
			if (f_class.equals("Economy class"))
				price = 7560;
			else if (f_class.equals("Travel class"))
				price = 3490;
			else
				price = 9990;
			break;
		}

	}

	public static void main(String[] args) {
		details();
		price = price * pass_num;
		discount = price * discount / 100;
		fare = price - discount;
		n_discount = fare * n_discount / 100;
		fare = fare - n_discount;
		System.out.println(Math.round(fare));

	}

}
