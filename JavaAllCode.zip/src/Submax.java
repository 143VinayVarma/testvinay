import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class Submax {
	static int a, b;
	static int[] arr;
	
	public static void details() {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of an array:");
		a = sc.nextInt();
		
		if(a<3 || a>20 )
		{sc.close();
			System.out.println(a +" is an invalid size");
			return;
			}
		arr=new int[a];
		System.out.println("Enter array elements:");
		for (int i = 0; i < arr.length; i++) {
			b = sc.nextInt();
			arr[i]=b;
		}
		sc.close();
		int bh[] = arr.clone();
		ArrayList<Integer> list=new ArrayList<Integer>();
		int max = Arrays.stream(arr).max().getAsInt(); 	
		for (int i = 0; i < bh.length; i++) {
			list.add(max-bh[i]);
				}
		for (int j = 0; j < list.size(); j++) {
		
				System.out.println(list.get(j));
			}
		
	}

	public static void main(String[] args) {
		details();
	}
}
