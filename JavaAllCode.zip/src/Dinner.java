import java.util.Scanner;

public class Dinner {
	public static void details() {
		int a, b;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the day interval of Sam:");
		a = sc.nextInt();
		System.out.println("Enter the day interval of Riya:");
		b = sc.nextInt();
		if (a <= 0 || b <= 0) {
			System.out.println(a + " to " + b + " is not a valid interval");
			System.exit(0);
		}
		sc.close();
		for (int i = 1; i <= a * b; i++) {
			if(a==1 || b==1 ||(a==1 && b==1))
			{
				if(a==1)
				System.out.println("Sam and Riya will have their dinner on day " + b);
				else
				{
					System.out.println("Sam and Riya will have their dinner on day " + a);
				}
				break;
			}
			else if (i % a == 0 && i % b == 0) {
				System.out.println("Sam and Riya will have their dinner on day " + i);
				break;
			}
		}

	}

	public static void main(String[] args) {
		details();
	}
}
