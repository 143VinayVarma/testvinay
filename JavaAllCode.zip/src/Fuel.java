import java.text.DecimalFormat;
import java.util.Scanner;

public class Fuel {
	static double ltr,distance;
	
	public static void scanner(double val, Scanner sc)
	{
		DecimalFormat df = new DecimalFormat("#.##");
		System.out.println(df.format(val) + " is an Invalid Input");
		sc.close();
		System.exit(0);
	}

	public static void mile2gallons(double ltr2, double distance2 )
	{
		double d=distance2*0.6214;
		double d2=ltr2*0.2642;
		float c=(float) (d/d2);
		System.out.println("Miles/gallons");
		System.out.printf("%.2f",c);
	}
	
	public static void ltrpKM(double ltr2, double distance2 )
	{
		System.out.println("Liters/100KM");
		double d=(ltr2/distance2)*100;
		DecimalFormat df = new DecimalFormat("0.00");
	System.out.println(df.format(d));
	}
	
	public static void details() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the no of liters to fill the tank");
		ltr = sc.nextDouble();
	 if(ltr <= 0.0) {
		 scanner(ltr, sc);}
	 System.out.println("Enter the distance covered");
		distance = sc.nextDouble();
	 if(distance <= 0.0) {
		 scanner(distance, sc);}
	 sc.close();
	 ltrpKM(ltr, distance);
	 mile2gallons(ltr, distance);
}
	
	public static void main(String[] args) {
		details();
	}
}
