import java.text.DecimalFormat;
import java.util.Scanner;

public class CarDetails {
static String carname;
static int CarNumber;
static double price;
public static void carDetails()
{
Scanner sc=new Scanner(System.in);
System.out.println("Enter the car name:");
carname=sc.next();
System.out.println("Enter the car no:");
CarNumber=sc.nextInt();
System.out.println("Enter the price:");
price=sc.nextDouble();
sc.close();

}
public static void main(String[] args) {
	DecimalFormat df = new DecimalFormat("0.00");
	carDetails();
	System.out.println("Car name:"+carname);
	System.out.println("Car no:"+CarNumber);
	System.out.println("Price:"+df.format(price)+" rs only");
}
}
