import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Scanner;

public class RF {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the size of Array:");
		int a = sc.nextInt();
		
		if(a<5 || a>10 )
		{
			sc.close();
			System.out.println(a +" is an invalid array size");
			return;
		}
		int[] arr=new int[a];
		for (int i = 0; i < arr.length; i++) {
			
			arr[i]=sc.nextInt();
		}
		sc.close();
		int b[] = arr.clone();
		LinkedHashMap<Integer, Integer> map1=new LinkedHashMap<>();
		//Arrays.sort(b);
		int c=0;
		for (int i = 0; i < b.length; i++) {
			map1.put(b[i], c++);
		}
		Arrays.sort(b);
		if(map1.size()>0)
		{
		System.out.print(map1.get(b[0]));
		}
		for (int j = 1; j < map1.size(); j++) {
			
			System.out.print(" "+map1.get(b[j]));
			}
		
		//Tree Map
//		TreeMap<Integer, Integer> map=new TreeMap<>();
//		
//		for (int i = 0; i < arr.length; i++) {
//			map.put(arr[i], d++);
//			
//		}
//		
//		System.out.println(" ");
//		for (Integer value: map.values()) {
//			System.out.print(value+" ");
//		}
		
	}

}
