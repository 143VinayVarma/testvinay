import java.util.Scanner;

public class CC02Prime {
	static int n1, n2, num, num1, k = 1, m = 1, a, b;
	static boolean flag = false;

	public static void m1(int j) {
		for (int i = 2; i < j / 2; i++) {
			if (j % i == 0) {
				flag = true;
				break;
			}
		}
		if (flag) {
			flag = false;
			m1(++num);
		}
	}

	public static void m2(int j) {
		for (int i = 2; i < j / 2; i++) {
			if (j % i == 0) {
				flag = true;
				break;
			}
		}
		if (flag) {
			flag = false;
			m1(--num1);
		}
	}

	public static void details() {
		

	}

	public static void main(String[] args) {

		//details();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the first number");
		n1 = sc.nextInt();
		
		System.out.println("Enter the last number");
		n2 = sc.nextInt();
		
		sc.close();
		if(n1<n2)
		{
			n1=n1+1;
			
		}
		a = n1;
		b = n2;
		num1 = a;
		if (n1 > n2) {
			int c = n1;
			n1 = n2;
			n2 = c;
			num = n2;
		//	 normalorder();

			// reverse way checking
			reverseorder();
		}

		else {
			num = n2;
			normalorder();
		}
	}

	public static void reverseorder() {

		for (int i = 2; i < num1 / 2; i++) {
			if (num1 % i == 0) {
				flag = true;
				break;
			}

		}
		if (flag) {
			flag = false;
			m2(--num1);
			while (num1 % 10 != 1) {
				m2(--num);
			}
		}
		while (a >= b) {
			boolean flag1 = false;
			for (int i = 2; i <= a / 2; ++i) {
				// condition for nonprime number
				if (a % i == 0) {
					flag1 = true;
					break;
				}
			}

			if (!flag1 && a != 0 && a != 1) {
				if (a % 10 == 1) {
					if (k == 1) {
						System.out.print(a);
						k++;
					} else {
						System.out.print("," + a);
					}
				}
			}
			--a;
		}
	}

	public static void normalorder() {
		int k = 0;
		// to write the last nearest prime number : remove if condition if last prime
		// if(b>a) {
		for (int i = 2; i < num / 2; i++) {
			if (num % i == 0) {
				flag = true;
				break;
			}

		}
		if (flag) {
			flag = false;
			m1(++num);
			while (num % 10 != 1) {
				m1(++num);
			}
		}
		// }

		while (n1 <= num) {
			boolean flag1 = false;

			for (int i = 2; i <= n1 / 2; ++i) {
				// condition for nonprime number
				if (n1 % i == 0) {
					flag1 = true;
					break;
				}
			}

			if (!flag1 && n1 != 0 && n1 != 1) {
				if (n1 % 10 == 1) {
					if (k == 0) {
						System.out.print(n1);
						k++;
					} else {
						System.out.print("," + n1);
					}
				}
			}
			++n1;
		}
	}
}
