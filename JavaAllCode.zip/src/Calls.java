import java.util.Scanner;

public class Calls {
	static int call, sms;
	static double callCharge, smsCharge, amount;

	public static void scanner(int val, Scanner sc) {
		if (val < 0) {
			System.out.println(val + " is an invalid input");
		} else {
			System.out.println(val + " exceeds the maximum limit");
		}
		sc.close();
		System.exit(0);
	}

	public static void callCharges(int call) {
		if (call == 0)
			callCharge = 0;
		else
			callCharge = ((call - 100) * 1.5);
	}

	public static void smsCharges(int sms) {
		if (sms == 0)
			smsCharge = 0;
		else
			smsCharge = ((sms - 100) * 0.5);
	}

	public static void details() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of calls:");
		call = sc.nextInt();
		if (call < 0 || call > 1000) {
			scanner(call, sc);
		}
		System.out.println("Enter the number of SMS:");
		sms = sc.nextInt();
		if (sms < 0 || sms > 1000) {
			scanner(sms, sc);
		}
		sc.close();
		if (call <= 100 && sms <= 100) {
			double tax = 150 * 5.5 / 100;
			amount = 150 + tax;
		} else {
			callCharges(call);
			smsCharges(sms);
			double tax = (callCharge + smsCharge + 150) * 5.5 / 100;
			amount = (150 + callCharge + smsCharge) + tax;

		}

	}

	public static void main(String[] args) {
		details();
		float c = (float) amount;
		System.out.printf("Amount to be paid is Rs.%.2f", c);
	}
}
