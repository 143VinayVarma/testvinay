package utilities;

public class Test {
	public static void main(String[] args) {
		int i=5,k=2;
				float x=((float)(i))/k;
				System.out.println(Math.round(x));
	}

}
