package utilities;

public class Sumofdigits {
	public static void main(String[] args) {
		int a=514,sum=0,x=0,y=0,z=0;
		while(a>0)
		{
			sum=sum+(a%10);
			a=a/10;
		}
		System.out.println("Sum ="+sum);
	
	while(a>0)
	{
		x=a%10;
		a=a/10;
		y=a%10;
		a=a/10;
		z=a%10;
		
		if(x==y || y==x || z==y)
		{
			System.out.println("Not Unique");
		}
		break;
	}
	
System.out.println(x+"\t"+y+"\t"+z);
}}
