package utilities;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class ZEEShop extends Thread {
	private String memberCategory;
	private static int count;
	private List<Member> memberList;
	static java.util.ArrayList<Member> list;
	static ZEEShop zs;

	public String memberCategory() {
		return this.memberCategory;
	}

	public void setmemberCategory(String memberCategory) {
		this.memberCategory = memberCategory;
	}

	public int getcount() {
		return this.count;
	}

	public void setcount(int count) {
		this.count = count;
	}

	public List<Member> getmemberList() {
		return this.memberList;
	}

	public void setCategory(List<Member> memberList) {
		this.memberList = memberList;
	}

	public ZEEShop(String memberCategory, List<Member> memberList) {
		this.memberCategory = memberCategory;
		this.memberList = memberList;
	}

	public static void main(String[] args) {
		System.out.println("Enter the number of Members:");
		Scanner scan = new Scanner(System.in);
		int memCount = scan.nextInt();

		list = new ArrayList<Member>();
		for (int i = 0; i < memCount; i++) {
			System.out.println("Enter the Member Details:");
			String num = scan.next();
			String arr[] = num.split(":");
			String memberId = arr[0];
			String memberName = arr[1];			
			String category = arr[2];
			if((category.equals("Platinum"))|| (category.equals("Silver")) ||(category.equals("Gold")))
			{}
			else
			{
				System.exit(0);
			}
			Member mem = new Member(memberId, memberName, category);
			list.add(mem);
		}

		

		System.out.println("Enter the number of times Membership category needs to be searched:");
		count = scan.nextInt();

		List<ZEEShop> zList = Collections.synchronizedList(new ArrayList<ZEEShop>());

		for (int i = 0; i < count; i++) {
			System.out.println("Enter the Category");
			String memberCateg = scan.next();
			if((memberCateg.equals("Platinum"))|| (memberCateg.equals("Silver")) ||(memberCateg.equals("Gold")))
		     {
			 zs = new ZEEShop(memberCateg, list);
			 zList.add(zs);}
			 else
			 {
				System.exit(0);
			 }

		}

		for (ZEEShop z : zList) {
			z.start();
			try {
				z.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public void run() {

		countTheCateory();
	}

	private void countTheCateory() {
		String id = null;
		int counter = 0;
		for (Member x : list) {
			id = x.getCategory();
			if (memberCategory.contentEquals(id)) {
				counter = counter + 1;
			}

		}
		System.out.println(memberCategory + ":" + counter);

	}
}
