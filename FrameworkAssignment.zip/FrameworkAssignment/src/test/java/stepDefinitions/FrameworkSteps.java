package stepDefinitions;

import java.io.File;
import java.util.concurrent.TimeUnit;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageObject.HomePage;
import pageObject.LoginPage;
import pageObject.PredefineData;
import pageObject.UserFeatures;

public class FrameworkSteps {
	static WebDriver driver;
	HomePage homePage;
	LoginPage loginPage;
	UserFeatures userfeaturePage;
	static PredefineData testdata;
	String Productquantity = RandomStringUtils.random(1, false, true);

	@Given("^load prerequisites$")
	public void load_prerequisites() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "./src/test/resources/Drivers/chromedriver.exe");
		driver = new ChromeDriver();
		testdata = new PredefineData();
		driver.get(testdata.property.getProperty("base_url"));
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.manage().window().fullscreen();
	}

	@Given("^login to application$")
	public void login_to_application() throws Throwable {
		homePage = new HomePage(driver);
		homePage.Click_login_from_MyAccount();
		loginPage = new LoginPage(driver);
		loginPage.provideEmail(testdata.property.getProperty("Email"));
		loginPage.providePassword(testdata.property.getProperty("password"));
		loginPage.ClickSubmitButton();
		Assert.assertEquals(loginPage.verifySuccessLogin(), "Account");

	}

	@When("^add item to Wishlist$")
	public void add_item_to_Wishlist() throws Throwable {
		userfeaturePage = new UserFeatures(driver);
		userfeaturePage.ClickHomePageButton();
		userfeaturePage.ClickIphoneProductViewButton();
		userfeaturePage.ClickWishlistAddButton();
		Assert.assertEquals(userfeaturePage.VerifyWishlistAddMessage(), "wish list");
		userfeaturePage.ClickHomePageButton();
	}

	@Then("^add to cart from productview$")
	public void add_to_cart_from_productview() throws Throwable {
		userfeaturePage = new UserFeatures(driver);
		userfeaturePage.ClickIphoneProductViewButton();
		userfeaturePage.ClickAddToCartButtonFromProductview();
		Assert.assertEquals(userfeaturePage.VerifyShoppingcartAddMessage(), "shopping cart");
		userfeaturePage.ClickHomePageButton();
	}

	@Then("^add to cart from wishlist$")
	public void add_to_cart_from_wishlist() throws Throwable {
		userfeaturePage.ClickWishlistViewButton();
		userfeaturePage.ClickAddToCartButtonFromWishlist();
		Assert.assertEquals(userfeaturePage.VerifyShoppingcartAddMessage(), "shopping cart");
		TakesScreenshot scrShot = ((TakesScreenshot) driver);
		File SrcFile = scrShot.getScreenshotAs(OutputType.FILE);
		File DestFile = new File("target/Screenshot/additem.png");
		FileUtils.copyFile(SrcFile, DestFile);		
		userfeaturePage.ClickHomePageButton();
	}

	@Then("^close the application$")
	public void close_the_application() throws Throwable {
		//userfeaturePage.ClickCartItem();
		//userfeaturePage.ClickShoppingCartViewButton();
		//userfeaturePage.RemoveCart();
		
		//Assert.assertEquals(userfeaturePage.VerifyShoppingcartAddMessage(), "shopping cart");
		//TakesScreenshot scrShot = ((TakesScreenshot) driver);
		//File SrcFile = scrShot.getScreenshotAs(OutputType.FILE);
		//File DestFile = new File("target/Screenshot/remoceitem.png");
		//FileUtils.copyFile(SrcFile, DestFile);
		loginPage.ClickLogoutButton();
		driver.close();
	}
}